from pathlib import Path
import sys,zipfile,struct,plistlib,hashlib
from macho_helpers import blobs
from validation_helpers import cmds,signature
APP='Payload/VVebo.app/'
base,target=map(Path,sys.argv[1:]);assert hashlib.sha256(base.read_bytes()).hexdigest()=='421cf67f08d72165b06b45d207f4c000b9db155c0ad66b1ba81cc423206ff71f'
with zipfile.ZipFile(base) as z:old={n:z.read(n) for n in z.namelist()}
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None;files={n:z.read(n) for n in z.namelist()}
assert set(files)==set(old)
assert {n for n in files if old[n]!=files[n]}=={APP+'VVebo',APP+'Info.plist',APP+'_CodeSignature/CodeResources'}
b=old[APP+'VVebo'];main=files[APP+'VVebo'];p=next(p for p,c,s in cmds(b) if c==0x32)
assert struct.unpack_from('<4I',b,p+8)==(2,0xe0000,0xf0500,1)
assert struct.unpack_from('<4I',main,p+8)==(2,0xe0000,0x120000,1)
so=next(p for p,c,s in cmds(b) if c==0x1d);off,size=struct.unpack_from('<II',b,so+8)
assert struct.unpack_from('<II',main,so+8)==(off,size)
expected=bytearray(b[:off]);struct.pack_into('<I',expected,p+16,0x120000)
assert main[:off]==expected,'Only one SDK field may change in the entire signed prefix'
for k in [5,7]:assert blobs(main).get(k)==blobs(b).get(k)
info=plistlib.loads(files[APP+'Info.plist']);oi=plistlib.loads(old[APP+'Info.plist'])
assert info['CFBundleDisplayName']=='VVebo 17G' and info['CFBundleVersion']=='4.1707'
assert info['UILaunchStoryboardName']=='Launch Screen' and 'UILaunchScreen' not in info
assert info['DTSDKName']==oi['DTSDKName']=='iphoneos15.5'
for k in ['CFBundleDisplayName','CFBundleVersion','VVProfile17DisplayCompatibility']:info.pop(k,None);oi.pop(k,None)
assert info==oi
res=plistlib.loads(files[APP+'_CodeSignature/CodeResources']);ores=plistlib.loads(old[APP+'_CodeSignature/CodeResources'])
for n,v in res['files'].items():
 if APP+n in files:assert (v['hash'] if isinstance(v,dict) else v)==hashlib.sha1(files[APP+n]).digest(),n
res['files'].pop('Info.plist');ores['files'].pop('Info.plist');assert res==ores
signature(main,files[APP+'Info.plist'],files[APP+'_CodeSignature/CodeResources'])
print('PASS: exactly 3 files differ; only one 4-byte declared SDK field changes before the main code signature; all instructions, imports, platform/minimum OS, geometry, linker tool metadata, frameworks, original storyboard and entitlements preserved. Info changes only name/build/experiment marker. ZIP and code/resource hashes validated.')
print('LIMIT: SDK declaration is not a recompile; changed runtime compatibility gates may affect more than display. Real screen geometry, launch/login, scrolling/keyboard and signing trust remain unverified.')
