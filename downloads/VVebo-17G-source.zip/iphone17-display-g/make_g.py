"""One-variable main Mach-O SDK-declaration experiment from verified E."""
from pathlib import Path
import sys,zipfile,struct,plistlib,hashlib,json
from macho_helpers import sign
from validation_helpers import cmds
APP='Payload/VVebo.app/'
E_HASH='421cf67f08d72165b06b45d207f4c000b9db155c0ad66b1ba81cc423206ff71f'
base,out=map(Path,sys.argv[1:]);assert hashlib.sha256(base.read_bytes()).hexdigest()==E_HASH
out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(base) as z:files={i.filename:z.read(i.filename) for i in z.infolist()};metas={i.filename:i for i in z.infolist()}
main=bytearray(files[APP+'VVebo']);build=[p for p,c,s in cmds(main) if c==0x32];assert len(build)==1;p=build[0]
platform,minimum,sdk,ntools=struct.unpack_from('<4I',main,p+8);assert (platform,minimum,sdk)==(2,0xe0000,0xf0500)
# Only the declared linked SDK changes. The file is NOT rebuilt against SDK 18.
# Minimum OS, platform, linker tool version, instructions, imports and layouts stay.
struct.pack_into('<I',main,p+16,0x120000)
info=plistlib.loads(files[APP+'Info.plist']);assert info['CFBundleVersion']=='4.1705'
assert info['UILaunchStoryboardName']=='Launch Screen' and 'UILaunchScreen' not in info
info['CFBundleDisplayName']='VVebo 17G';info['CFBundleVersion']='4.1707'
info['VVProfile17DisplayCompatibility']='main-sdk-declaration-18-g'
# Keep original Xcode/DTSDK build-history metadata truthful; no new build claimed.
files[APP+'Info.plist']=plistlib.dumps(info,fmt=plistlib.FMT_BINARY,sort_keys=False)
rp=APP+'_CodeSignature/CodeResources';res=plistlib.loads(files[rp]);old=res['files']['Info.plist'];h=hashlib.sha1(files[APP+'Info.plist']).digest()
if isinstance(old,dict):old=dict(old);old['hash']=h
else:old=h
res['files']['Info.plist']=old;files[rp]=plistlib.dumps(res,fmt=plistlib.FMT_XML,sort_keys=True)
files[APP+'VVebo'],_=sign(main,info['CFBundleIdentifier'],files[APP+'Info.plist'],files[rp])
target=out/'VVebo-3.3.31-iPhone17-Display-G.ipa'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,data in files.items():
  old=metas[n];zi=zipfile.ZipInfo(n,old.date_time);zi.external_attr=old.external_attr;zi.create_system=old.create_system;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,data)
manifest={'baseline':'User-confirmed E; F launch declaration experiment not included','baseline_sha256':E_HASH,'build_version_command_offset':hex(p),'sdk_field_offset':hex(p+16),'declared_main_sdk_before':'15.5','declared_main_sdk_after':'18.0','actual_recompile':False,'minimum_os':'14.0 unchanged','build':'4.1707','status':'Untested linked-SDK compatibility behavior experiment; may alter runtime behavior beyond screen geometry','sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(out/'iPhone17-G-change-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(target.name,target.stat().st_size,manifest['sha256'])
