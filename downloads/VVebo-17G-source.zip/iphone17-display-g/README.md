# VVebo 17G: main linked-SDK declaration experiment

E is user-confirmed to launch without crashes and load profiles. Thin black edge lines remain. User confirmed F's launch-screen-only experiment did not remove them. G starts from exact E, restoring the original launch-storyboard selection by construction.

The actual main Mach-O has LC_BUILD_VERSION at file offset 0x10f8: platform iOS, minimum 14.0, declared linked SDK 15.5. G changes ONLY its 32-bit SDK field at 0x1108 from 0x000f0500 to 0x00120000 (18.0). The choice tests newer linked-on-or-after compatibility behavior from the period newer Pro Max screen dimensions were introduced. It does not establish which private UIKit compatibility threshold applies, whether this app is letterboxed by that threshold, or whether this change will remove the lines.

This is NOT recompilation against SDK 18, a new UIKit implementation, or a completed iPhone 17 resolution port. The original Info.plist Xcode/DTSDK build history remains 15.5 rather than claiming a newer compiler. Build/display name identifies this experiment as VVebo 17G / 4.1707.

Changing the main SDK declaration can activate OS/SwiftUI compatibility rules beyond screen sizing, potentially affecting layout, scrolling, keyboard or other behavior. Keep E as the known-working fallback and verify on-device. No actual runtime success is claimed by offline validation.

Only three IPA files change: main binary signature/header field, Info.plist version/experiment marker, and the corresponding CodeResources Info hash. All instruction bytes (including E cloud cancellation), symbols/imports, frameworks (including E homepage adapter), minimum OS, platform, linker version, section layout, original launch storyboard/assets and entitlements remain unchanged. No F changes, injected window hooks, hardcoded physical resolution, safe-area edits, data clearing or new helper code.

Python 3 standard library only:

    python make_g.py /path/to/E.ipa /path/to/output
    python verify_g.py /path/to/E.ipa /path/to/output/VVebo-3.3.31-iPhone17-Display-G.ipa

Verified E SHA256: 421cf67f08d72165b06b45d207f4c000b9db155c0ad66b1ba81cc423206ff71f.

Verification compares the entire main prefix before its code signature against E with exactly one SDK field substituted. It validates file/settings scope, original permissions/resources, SHA256 code hashes and ZIP integrity. New ARM64 implementation tests are unnecessary because no executable instructions change; existing mocked tests would not exercise UIKit compatibility logic. Physical screen results, OS compatibility interpretation, launch/login, scrolling/keyboard and signing trust require the actual device.

No user crash logs, signed IPAs, profiles, certificates or device identifiers are included.
