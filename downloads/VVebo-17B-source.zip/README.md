# iPhone17 Cloud compatibility B

User-approved experiment disabling unavailable CloudKit container requests. The working iOS15 Profile A binary is the immutable baseline. No change is made to its networking framework.

Requires Python 3. Use the exact baseline IPA (SHA-256 asserted by the packager):

    python make_b.py /path/to/VVebo-3.3.31-iOS15-Profile-A.ipa /path/to/output
    python verify_b.py /path/to/VVebo-3.3.31-iOS15-Profile-A.ipa /path/to/output/VVebo-3.3.31-iPhone17-CloudCompat-B.ipa

The instruction-slice checks additionally require Python package unicorn:

    python test_cloud_arm64.py /path/to/VVebo-3.3.31-iOS15-Profile-A.ipa /path/to/output/VVebo-3.3.31-iPhone17-CloudCompat-B.ipa

Six verified `objc_msgSend(defaultContainer)` calls in the original CloudCenter are replaced with `mov x0, #0`. The original initializer sends `publicCloudDatabase` to the returned object and stores the result; its instruction slice has been checked with nil-return semantics. This is targeted feature disablement, not authorization spoofing.

The test executes real instruction slices. Runtime and CloudKit calls are mocked. It does not prove complete initialization or safety of every later nil-database use. Cloud-related operations may remain unavailable or require further handling. No on-device success is claimed.

Only the main Mach-O, Info.plist and root CodeResources change. Entitlement blobs and all networking framework bytes remain unchanged. Display name VVebo 17B, build 4.1702. Normal user signing remains required; no private signing material or device identifier is included.
