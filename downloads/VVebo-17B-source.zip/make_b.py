from pathlib import Path
import zipfile,plistlib,struct,hashlib,json,sys
from macho_helpers import sign
if len(sys.argv)!=3:raise SystemExit('Usage: make_b.py VERIFIED_15A_IPA OUTPUT_DIRECTORY')
base=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
assert hashlib.sha256(base.read_bytes()).hexdigest()=='46c2c14389780a5a7743b435439b58e5ebe3d3c4e1bf6552b490b49ee84224b6'
APP='Payload/VVebo.app/'
# These six direct Objective-C message sends load the defaultContainer selector.
# Replacing only that send with a nil result disables unavailable CloudKit containers.
# No SDK API or entitlement is forged, and no method is globally swizzled for CloudKit.
OFFSETS=[0x3096b4,0x309c04,0x309d0c,0x30a4c0,0x30ba70,0x30bd20]
TARGET=0x565578
NIL_RESULT=bytes.fromhex('000080d2') # mov x0, #0
with zipfile.ZipFile(base) as z:
 files={i.filename:z.read(i.filename) for i in z.infolist()};meta={i.filename:i for i in z.infolist()}
original=files[APP+'VVebo'];main=bytearray(original);manifest=[]
for off in OFFSETS:
 word=struct.unpack_from('<I',main,off)[0]
 assert word&0xfc000000==0x94000000
 imm=word&0x3ffffff
 if imm&(1<<25):imm-=1<<26
 assert off+(imm<<2)==TARGET
 manifest.append({'file_offset':hex(off),'before':main[off:off+4].hex(),'after':NIL_RESULT.hex()})
 main[off:off+4]=NIL_RESULT
info=plistlib.loads(files[APP+'Info.plist']);assert info['VVProfile15Build']=='a'
info['CFBundleDisplayName']='VVebo 17B';info['CFBundleVersion']='4.1702'
info['VVProfile17Compatibility']='cloud-containers-disabled-b'
files[APP+'Info.plist']=plistlib.dumps(info,fmt=plistlib.FMT_BINARY,sort_keys=False)
resourcepath=APP+'_CodeSignature/CodeResources';resources=plistlib.loads(files[resourcepath])
legacy=resources.setdefault('files',{})
if 'Info.plist' in legacy:
 prior=legacy['Info.plist'];digest=hashlib.sha1(files[APP+'Info.plist']).digest()
 if isinstance(prior,dict):prior=dict(prior);prior['hash']=digest;legacy['Info.plist']=prior
 else:legacy['Info.plist']=digest
files[resourcepath]=plistlib.dumps(resources,fmt=plistlib.FMT_XML,sort_keys=True)
files[APP+'VVebo'],_=sign(main,info['CFBundleIdentifier'],files[APP+'Info.plist'],files[resourcepath])
target=out/'VVebo-3.3.31-iPhone17-CloudCompat-B.ipa'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in files.items():
  old=meta[name];m=zipfile.ZipInfo(name,old.date_time);m.external_attr=old.external_attr;m.create_system=old.create_system;m.compress_type=zipfile.ZIP_DEFLATED;z.writestr(m,data)
(out/'iPhone17-B-patch-manifest.json').write_text(json.dumps({'baseline':'VVebo 15A','scope':'User-approved disablement of unavailable CloudKit container requests; networking framework unchanged','instruction_patches':manifest},indent=2)+'\n')
print(target.name,'bytes',target.stat().st_size,'SHA256',hashlib.sha256(target.read_bytes()).hexdigest())
