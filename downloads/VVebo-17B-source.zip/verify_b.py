from pathlib import Path
import zipfile,plistlib,struct,hashlib,sys
from validation_helpers import cmds,signature
from macho_helpers import blobs
OFFSETS=[0x3096b4,0x309c04,0x309d0c,0x30a4c0,0x30ba70,0x30bd20]
if len(sys.argv)!=3:raise SystemExit('Usage: verify_b.py BASELINE_A_IPA COMPAT_B_IPA')
a=Path(sys.argv[1]);b=Path(sys.argv[2]);APP='Payload/VVebo.app/'
assert hashlib.sha256(a.read_bytes()).hexdigest()=='46c2c14389780a5a7743b435439b58e5ebe3d3c4e1bf6552b490b49ee84224b6'
with zipfile.ZipFile(a) as z:original={n:z.read(n) for n in z.namelist()}
with zipfile.ZipFile(b) as z:
 assert z.testzip() is None;files={n:z.read(n) for n in z.namelist()}
assert set(files)==set(original)
assert {n for n in files if files[n]!=original[n]}=={APP+'VVebo',APP+'Info.plist',APP+'_CodeSignature/CodeResources'}
main=files[APP+'VVebo'];base=original[APP+'VVebo']
def text_range(binary):
 for p,c,s in cmds(binary):
  if c!=0x19:continue
  for i in range(struct.unpack_from('<I',binary,p+64)[0]):
   q=p+72+i*80
   if binary[q:q+16].split(b'\0')[0]==b'__text':
    size,off=struct.unpack_from('<QI',binary,q+40);return off,off+size
 raise AssertionError('__text missing')
lo,hi=text_range(base);expected=bytearray(base[lo:hi])
for off in OFFSETS:
 word=struct.unpack_from('<I',base,off)[0];assert word&0xfc000000==0x94000000
 imm=word&0x3ffffff
 if imm&(1<<25):imm-=1<<26
 assert off+(imm<<2)==0x565578
 expected[off-lo:off-lo+4]=bytes.fromhex('000080d2')
assert main[lo:hi]==bytes(expected),'Unexpected instruction changes'
info=plistlib.loads(files[APP+'Info.plist']);oldinfo=plistlib.loads(original[APP+'Info.plist'])
assert info['CFBundleDisplayName']=='VVebo 17B' and info['CFBundleVersion']=='4.1702'
assert info['VVProfile17Compatibility']=='cloud-containers-disabled-b'
for k in ['CFBundleDisplayName','CFBundleVersion','VVProfile17Compatibility']:info.pop(k,None);oldinfo.pop(k,None)
assert info==oldinfo
signature(main,files[APP+'Info.plist'],files[APP+'_CodeSignature/CodeResources'])
for k in [5,7]:assert blobs(main).get(k)==blobs(base).get(k),'Entitlements changed'
assert files[APP+'Frameworks/VVProfile15.framework/VVProfile15']==original[APP+'Frameworks/VVProfile15.framework/VVProfile15']
print('PASS: B differs from verified A in exactly 3 files; instruction changes are exactly 6 defaultContainer sends changed to nil results; networking framework and all other files unchanged; build markers, entitlements and code/resource signatures validated.')
print('NOT VERIFIED: device trust, launch, complete CloudCenter initialization, other nil-database uses, live profiles/pagination, or display adaptation.')
