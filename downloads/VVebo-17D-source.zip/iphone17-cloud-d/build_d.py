from pathlib import Path
import struct,subprocess,os,zipfile,json,sys,hashlib
from macho_imports import imports
ROOT=Path(__file__).resolve().parent
A=ROOT.parent/'ios15-profile-a'
def symbols(b):
 p=32
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  c,s=struct.unpack_from('<II',b,p)
  if c==2:so,n,st,sz=struct.unpack_from('<4I',b,p+8)
  p+=s
 out={}
 for i in range(n):
  no,t,se,d,v=struct.unpack_from('<IBBHQ',b,so+16*i)
  if no:out[b[st+no:b.find(b'\0',st+no)].decode()]=(t,se,v)
 return out
if __name__=='__main__':
 env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(ROOT.parent/'zig-cache'),ZIG_LOCAL_CACHE_DIR=str(ROOT.parent/'zig-local-cache'))
 zig=os.environ.get('ZIG_BIN',str(ROOT.parent/'build-tools/ziglang/zig'))
 subprocess.run([zig,'cc','-target','aarch64-ios.14.0','-fobjc-arc','-fobjc-runtime=ios-14.0','-fblocks','-mno-outline-atomics','-O2','-g0','-Wall','-Wextra','-Werror','-c',str(ROOT/'CloudFailure.m'),'-o',str(ROOT/'CloudFailure.o')],check=True,env=env)
 subprocess.run([zig,'cc','-target','aarch64-ios.14.0','-g0','-c',str(ROOT/'gates.S'),'-o',str(ROOT/'gates.o')],check=True,env=env)
 providers={}
 baseline=Path(sys.argv[1])
 assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='46c2c14389780a5a7743b435439b58e5ebe3d3c4e1bf6552b490b49ee84224b6'
 with zipfile.ZipFile(baseline) as z:
  for n in ['Payload/VVebo.app/VVebo','Payload/VVebo.app/Frameworks/Alamofire.framework/Alamofire','Payload/VVebo.app/Frameworks/VVProfile15.framework/VVProfile15']:
   for sym,lib in imports(z.read(n)).items():providers.setdefault(sym,lib)
 groups={}
 for obj in [A/'VVProfile15.o',ROOT/'CloudFailure.o']:
  for sym,(t,_,_) in symbols(obj.read_bytes()).items():
   if t==1:groups.setdefault(providers[sym],set()).add(sym)
 stubs=ROOT/'stubs';stubs.mkdir(exist_ok=True)
 for i,(lib,syms) in enumerate(sorted(groups.items())):
  (stubs/f'{i}.tbd').write_text("--- !tapi-tbd\ntbd-version: 4\ntargets: [ arm64-ios ]\ninstall-name: '"+lib+"'\ncurrent-version: 1\ncompatibility-version: 1\nexports:\n  - targets: [ arm64-ios ]\n    symbols: [ "+', '.join("'"+s+"'" for s in sorted(syms))+" ]\n...\n")
 (ROOT/'import-providers.json').write_text(json.dumps({s:lib for lib,syms in groups.items() for s in sorted(syms)},indent=2)+'\n')
 subprocess.run([os.environ.get('LD64_LLD_BIN',str(ROOT.parent/'llvm-tools/usr/lib/llvm-19/bin/ld64.lld')),'-dylib','-arch','arm64','-platform_version','ios','14.0','15.5','-install_name','@rpath/VVProfile15.framework/VVProfile15','-current_version','2.0','-compatibility_version','1.0','-headerpad','0x1000','-dead_strip','-adhoc_codesign','-o',str(ROOT/'VVProfile15'),str(A/'VVProfile15.o'),str(ROOT/'CloudFailure.o')]+[str(p) for p in sorted(stubs.glob('*.tbd'))],check=True)
 print('Built framework with unchanged A networking object and CloudFailure.o')
