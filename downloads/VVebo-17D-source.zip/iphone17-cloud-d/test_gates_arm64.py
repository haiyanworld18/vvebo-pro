"""Execute inserted main-binary ARM64 gates; dlsym/helpers/releases are mocked."""
import zipfile,struct,sys
from pathlib import Path
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
from make_d import gate_code
import json
plan=json.loads((Path(__file__).parent/'plan.json').read_text());code,gates=gate_code(plan)
BASE=0x100000000;STOP=0x300000;HELPER=0x301000;SP=0x20fff0
with zipfile.ZipFile(sys.argv[1]) as z:main=z.read('Payload/VVebo.app/VVebo')
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x800000);u.mem_write(BASE,main);u.mem_map(0x200000,0x20000);u.mem_map(STOP,0x2000)
calls=[];resolved=True
regs=[UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2]
def ret(v):u.reg_write(UC_ARM64_REG_X0,v);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
def hook(u,a,s,d):
 if a==BASE+plan['dlsym_stub_offset']:
  assert u.reg_read(UC_ARM64_REG_X0)==0xfffffffffffffffe
  p=u.reg_read(UC_ARM64_REG_X1);name=bytes(u.mem_read(p,32)).split(b'\0')[0].decode();calls.append(('lookup',name));ret(HELPER if resolved else 0)
 elif a==HELPER:calls.append(('helper',*[u.reg_read(r) for r in regs]));ret(0)
 elif a==BASE+plan['bridge_release_stub_offset']:calls.append(('release',u.reg_read(UC_ARM64_REG_X0)));ret(0)
u.hook_add(UC_HOOK_CODE,hook)
def run(gate,values):
 calls.clear();u.reg_write(UC_ARM64_REG_SP,SP);u.reg_write(UC_ARM64_REG_LR,STOP);u.reg_write(UC_ARM64_REG_FP,0xabcdef)
 for i in range(19,29):u.reg_write(globals()['UC_ARM64_REG_X'+str(i)],0xa000+i)
 for r,v in zip(regs,values):u.reg_write(r,v)
 u.emu_start(BASE+gates[gate],STOP,count=1000)
 assert u.reg_read(UC_ARM64_REG_PC)==STOP and u.reg_read(UC_ARM64_REG_SP)==SP and u.reg_read(UC_ARM64_REG_FP)==0xabcdef
 for i in range(19,29):assert u.reg_read(globals()['UC_ARM64_REG_X'+str(i)])==0xa000+i
for kind in ['Pair','Triple']:
 resolved=True;run('_VVGate'+kind,[0,0x5555,0x6666]);assert calls==[('lookup','VVCloudFail'+kind),('helper',0,0x5555,0x6666)]
 resolved=False;run('_VVGate'+kind,[0,0x5555,0x6666]);assert calls==[('lookup','VVCloudFail'+kind)]
for arrays in [(0,0),(0x1111,0),(0,0x2222),(0x1111,0x2222)]:
 run('_VVGateConstructor',[*arrays,0]);assert calls==[('release',arrays[0]),('release',arrays[1])];assert u.reg_read(UC_ARM64_REG_X0)==0
print('PASS: packaged ARM64 pair/triple gates preserve arguments, stack/FP and callee-saved registers; missing symbols return safely; constructor gate consumes each owned array exactly once and returns nil.')
print('LIMIT: runtime symbol resolution and Swift reference-counting functions are mocked.')
