from pathlib import Path
import zipfile,plistlib,struct,hashlib,sys
from validation_helpers import cmds,signature,section_bytes
from macho_helpers import blobs
from make_d import APP,FW,GATE_OFFSET,gate_code,branch,CONTAINERS
from macho_plan import make_plan
from build_d import symbols
from macho_imports import imports
base,target=map(Path,sys.argv[1:]);assert hashlib.sha256(base.read_bytes()).hexdigest()=='46c2c14389780a5a7743b435439b58e5ebe3d3c4e1bf6552b490b49ee84224b6'
with zipfile.ZipFile(base) as z:old={n:z.read(n) for n in z.namelist()}
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None;files={n:z.read(n) for n in z.namelist()}
assert set(files)==set(old)
changed={APP+'VVebo',APP+'Info.plist',APP+'_CodeSignature/CodeResources',APP+FW+'VVProfile15',APP+FW+'Info.plist'}
assert {n for n in files if files[n]!=old[n]}==changed
b=old[APP+'VVebo'];main=files[APP+'VVebo'];plan=make_plan(b);code,gates=gate_code(plan)
expected=bytearray(b[0x66d8:0x561594])
patches={off:bytes.fromhex('000080d2') for off in CONTAINERS+[a['file_offset'] for a in plan['allocations']]}
for row in plan['constructors']:patches[row['file_offset']]=branch(row['file_offset'],gates['_VVGateConstructor'])
for row in plan['completions']:patches[row['file_offset']]=branch(row['file_offset'],gates['_VVGatePair' if row['kind']=='pair' else '_VVGateTriple'])
assert len(patches)==51
for off,val in patches.items():expected[off-0x66d8:off-0x66d8+4]=val
assert main[0x66d8:0x561594]==expected
assert main[GATE_OFFSET:GATE_OFFSET+len(code)]==code
assert section_bytes(main,b'__text')==main[GATE_OFFSET:0x561594]
# C's skipped account query call sites have been restored to A.
for off in [0x241944,0xc9220]:assert main[off:off+4]==b[off:off+4]
info=plistlib.loads(files[APP+'Info.plist']);oi=plistlib.loads(old[APP+'Info.plist'])
assert info['CFBundleDisplayName']=='VVebo 17D' and info['CFBundleVersion']=='4.1704'
for k in ['CFBundleDisplayName','CFBundleVersion','VVProfile17Compatibility']:info.pop(k,None);oi.pop(k,None)
assert info==oi
signature(main,files[APP+'Info.plist'],files[APP+'_CodeSignature/CodeResources'])
for k in [5,7]:assert blobs(main).get(k)==blobs(b).get(k)
fw=files[APP+FW+'VVProfile15'];_,cdhash=signature(fw)
res=plistlib.loads(files[APP+'_CodeSignature/CodeResources'])
assert res['files2']['Frameworks/VVProfile15.framework']['cdhash']==cdhash
for n,v in res['files'].items():
 if APP+n in files:assert (v['hash'] if isinstance(v,dict) else v)==hashlib.sha1(files[APP+n]).digest(),n
syms=symbols(fw)
for s in ['_VVCloudFailPair','_VVCloudFailTriple']:assert syms[s][0]==15
for p,c,s in cmds(fw):
 if c==0x80000022:export_offset,export_size=struct.unpack_from('<II',fw,p+40)
 if c==0x80000033:export_offset,export_size=struct.unpack_from('<II',fw,p+8)
 if c==0x19:
  va,vs,fo,fs=struct.unpack_from('<4Q',fw,p+24);assert va%16384==0 and fo%16384==0
def uleb(pos):
 value=shift=0
 while True:
  byte=fw[pos];pos+=1;value|=(byte&127)<<shift
  if not byte&128:return value,pos
  shift+=7
exports=set()
def walk_export(offset,name):
 size,pos=uleb(export_offset+offset)
 if size:exports.add(name)
 pos+=size;count=fw[pos];pos+=1
 for _ in range(count):
  end=fw.index(0,pos);part=fw[pos:end].decode();child,pos=uleb(end+1);walk_export(child,name+part)
walk_export(0,'')
assert {'_VVCloudFailPair','_VVCloudFailTriple'}<=exports,'Helpers must be visible to dyld dlsym'
assert '_OBJC_CLASS_$_NSError' in imports(fw)
assert not any('CloudKit' in lib for lib in imports(fw).values())
print('PASS: exact 5 changed files; 51 instruction replacements, bounded gate insertion and text extent; all original C-skipped callers restored; original entitlements preserved; SHA256 code/resource hashes, 16KB framework alignment and public helper symbols validated.')
print('LIMIT: static signing hashes do not validate certificate trust or device launch. User login, callback behavior on iOS and network service still require device verification.')
