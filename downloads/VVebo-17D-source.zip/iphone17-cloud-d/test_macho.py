import struct
def parse(b):
 p=32;segs=[];syms=None;ind=None;stubsec=None;selectors=[]
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  c,s=struct.unpack_from('<II',b,p)
  if c==2:syms=struct.unpack_from('<4I',b,p+8)
  if c==0xb:ind=struct.unpack_from('<II',b,p+56)
  if c==0x19:
   vm,vs,fo,fs=struct.unpack_from('<4Q',b,p+24);segs.append((vm,vs,fo,fs))
   for i in range(struct.unpack_from('<I',b,p+64)[0]):
    q=p+72+80*i
    if b[q:q+16].split(b'\0')[0]==b'__objc_selrefs':
     va,size,fo=struct.unpack_from('<QQI',b,q+32)
     for j in range(0,size,8):selectors.append((va+j,struct.unpack_from('<Q',b,fo+j)[0]&0xfffffffff))
    if b[q:q+16].split(b'\0')[0]==b'__stubs':
     va,size=struct.unpack_from('<QQ',b,q+32);first,entrysize=struct.unpack_from('<II',b,q+68);stubsec=(va,size,first,entrysize)
  p+=s
 so,n,st,ss=syms;symbols=[];addresses={}
 for i in range(n):
  no,t,se,d,v=struct.unpack_from('<IBBHQ',b,so+16*i);name=b[st+no:st+ss].split(b'\0')[0].decode();symbols.append(name)
  if not t&0xe0 and t&0xe==0xe:addresses[name]=v
 va,size,first,entrysize=stubsec;io,ic=ind;stubs={}
 for i in range(size//entrysize):
  si=struct.unpack_from('<I',b,io+4*(first+i))[0];stubs[va+entrysize*i]=symbols[si]
 return segs,addresses,stubs,selectors

