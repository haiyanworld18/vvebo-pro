from pathlib import Path
import zipfile,plistlib,struct,hashlib,json,sys
from macho_helpers import sign,blobs
from validation_helpers import cmds,section_bytes
from build_d import symbols
from macho_plan import make_plan
ROOT=Path(__file__).resolve().parent
APP='Payload/VVebo.app/';FW='Frameworks/VVProfile15.framework/'
GATE_OFFSET=0x3400
CONTAINERS=[0x3096b4,0x309c04,0x309d0c,0x30a4c0,0x30ba70,0x30bd20]
def branch(off,target):
 delta=target-off;assert delta%4==0 and -(1<<27)<=delta<(1<<27)
 return struct.pack('<I',0x94000000|((delta//4)&0x3ffffff))
def gate_code(plan):
 obj=(ROOT/'gates.o').read_bytes();code=bytearray(section_bytes(obj,b'__text'));syms=symbols(obj)
 for p,c,s in cmds(obj):
  if c==0x19:
   for i in range(struct.unpack_from('<I',obj,p+64)[0]):
    q=p+72+i*80;assert struct.unpack_from('<I',obj,q+60)[0]==0,'Gate must have no relocations'
 mappings={syms['_VVLookupTarget'][2]:plan['dlsym_stub_offset'],syms['_VVReleaseTarget'][2]:plan['bridge_release_stub_offset']}
 for off in range(0,len(code),4):
  word=struct.unpack_from('<I',code,off)[0]
  if word&0xfc000000!=0x94000000:continue
  delta=word&0x3ffffff
  if delta&(1<<25):delta-=1<<26
  target=off+(delta<<2);assert target in mappings
  code[off:off+4]=branch(GATE_OFFSET+off,mappings[target])
 return bytes(code),{n:GATE_OFFSET+syms[n][2] for n in ['_VVGatePair','_VVGateTriple','_VVGateConstructor']}
def main():
 base=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=True,parents=True)
 assert hashlib.sha256(base.read_bytes()).hexdigest()=='46c2c14389780a5a7743b435439b58e5ebe3d3c4e1bf6552b490b49ee84224b6'
 with zipfile.ZipFile(base) as z:
  files={i.filename:z.read(i.filename) for i in z.infolist()};meta={i.filename:i for i in z.infolist()}
 original=files[APP+'VVebo'];main=bytearray(original);plan=make_plan(original);code,gates=gate_code(plan)
 assert plan['load_commands_end']<=GATE_OFFSET and GATE_OFFSET+len(code)<plan['main_text_offset']
 assert not any(main[GATE_OFFSET:GATE_OFFSET+len(code)])
 main[GATE_OFFSET:GATE_OFFSET+len(code)]=code
 patches=[]
 def patch(off,value,reason):
  assert struct.unpack_from('<I',original,off)[0]&0xfc000000==0x94000000
  patches.append({'file_offset':hex(off),'before':original[off:off+4].hex(),'after':value.hex(),'purpose':reason});main[off:off+4]=value
 for off in CONTAINERS:patch(off,bytes.fromhex('000080d2'),'Disabled cloud container: nil')
 for row in plan['allocations']:patch(row['file_offset'],bytes.fromhex('000080d2'),'Disabled operation allocation: nil')
 for row in plan['constructors']:patch(row['file_offset'],branch(row['file_offset'],gates['_VVGateConstructor']),'Consume owned Swift arrays and return nil operation')
 for row in plan['completions']:patch(row['file_offset'],branch(row['file_offset'],gates['_VVGatePair' if row['kind']=='pair' else '_VVGateTriple']),'Asynchronous ordinary NSError completion, '+row['kind'])
 for p,c,s in cmds(main):
  if c==0x19:
   for i in range(struct.unpack_from('<I',main,p+64)[0]):
    q=p+72+i*80
    if main[q:q+16].split(b'\0')[0]==b'__text':
     va,sz,fo=struct.unpack_from('<QQI',main,q+32);assert fo==plan['main_text_offset']
     struct.pack_into('<QQI',main,q+32,0x100000000+GATE_OFFSET,fo+sz-GATE_OFFSET,GATE_OFFSET)
 info=plistlib.loads(files[APP+'Info.plist']);info['CFBundleDisplayName']='VVebo 17D';info['CFBundleVersion']='4.1704';info['VVProfile17Compatibility']='cloud-operations-disabled-with-async-errors-d'
 files[APP+'Info.plist']=plistlib.dumps(info,fmt=plistlib.FMT_BINARY,sort_keys=False)
 fw=(ROOT/'VVProfile15').read_bytes();files[APP+FW+'VVProfile15']=fw
 fi=plistlib.loads(files[APP+FW+'Info.plist']);fi['CFBundleVersion']='2';fi['CFBundleShortVersionString']='2.0'
 files[APP+FW+'Info.plist']=plistlib.dumps(fi,fmt=plistlib.FMT_XML,sort_keys=True)
 respath=APP+'_CodeSignature/CodeResources';res=plistlib.loads(files[respath]);legacy=res['files']
 for rel in ['Info.plist',FW+'Info.plist',FW+'VVProfile15']:
  prior=legacy.get(rel);digest=hashlib.sha1(files[APP+rel]).digest()
  if isinstance(prior,dict):prior=dict(prior);prior['hash']=digest;legacy[rel]=prior
  else:legacy[rel]=digest
 cdhash=hashlib.sha256(blobs(fw)[0]).digest()[:20]
 res['files2']['Frameworks/VVProfile15.framework']={'cdhash':cdhash,'requirement':'cdhash H"'+cdhash.hex()+'"'}
 files[respath]=plistlib.dumps(res,fmt=plistlib.FMT_XML,sort_keys=True)
 files[APP+'VVebo'],_=sign(main,info['CFBundleIdentifier'],files[APP+'Info.plist'],files[respath])
 target=out/'VVebo-3.3.31-iPhone17-CloudCompat-D.ipa'
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,data in files.items():
   m=meta[name];zi=zipfile.ZipInfo(name,m.date_time);zi.external_attr=m.external_attr;zi.create_system=m.create_system;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,data)
 manifest={'baseline':'15A; C caller skips are NOT included','gate_offset':hex(GATE_OFFSET),'gate_size':len(code),'gates':gates,'patches':patches,'operation_creations_disabled':23,'completion_setters':22,'network_object_sha256':hashlib.sha256((ROOT.parent/'ios15-profile-a/VVProfile15.o').read_bytes()).hexdigest(),'ipa_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
 (out/'iPhone17-D-patch-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(target.name,target.stat().st_size,manifest['ipa_sha256'])
if __name__=='__main__':main()
