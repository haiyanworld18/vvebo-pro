"""Run compiled failure helpers and queued blocks, mocking dispatch/Foundation/ARC."""
import sys,struct
from pathlib import Path
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
from test_macho import parse
b=Path(sys.argv[1]).read_bytes();segs,symbols,stubs,selectors=parse(b)
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
for va,sz in [(0,0x50000),(0x100000,0x20000),(0x200000,0x20000),(0x300000,0x10000)]:u.mem_map(va,sz)
for va,vs,fo,fs in segs:
 if fs:u.mem_write(va,b[fo:fo+fs])
selnames={}
for va,p in selectors:
 u.mem_write(va,struct.pack('<Q',p));selnames[p]=bytes(u.mem_read(p,128)).split(b'\0')[0].decode()
STOP=0x300000;CALLBACK=0x301000;BLOCK=0x100000;COPIED=0x101000;DICT=0x102000;ERROR=0x103000;QUEUE=0x104000
u.mem_write(BLOCK,struct.pack('<QIIQQ',0,0,0,CALLBACK,0))
queued=[];events=[];copied=0
regs=[UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]
def ret(v):u.reg_write(UC_ARM64_REG_X0,v);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
def hook(u,a,s,d):
 global copied
 x=[u.reg_read(r) for r in regs]
 if a==CALLBACK:events.append(('callback',*x));ret(0);return
 name=stubs.get(a)
 if not name:return
 if name=='_objc_msgSend':
  sel=selnames[x[1]]
  if sel=='copy':assert x[0]==BLOCK;copied+=1;ret(BLOCK)
  elif sel=='dictionaryWithObjects:forKeys:count:':assert u.reg_read(UC_ARM64_REG_X4)==1;ret(DICT)
  elif sel=='errorWithDomain:code:userInfo:':
   # fourth explicit argument goes in x4.
   assert x[3]==1 and u.reg_read(UC_ARM64_REG_X4)==DICT;ret(ERROR)
  else:raise AssertionError(('selector',sel))
 elif name=='_dispatch_get_global_queue':assert x[:2]==[0,0];ret(QUEUE)
 elif name=='_dispatch_async':
  assert x[0]==QUEUE and not events
  descriptor=struct.unpack('<Q',u.mem_read(x[1]+24,8))[0];size=struct.unpack('<Q',u.mem_read(descriptor+8,8))[0]
  assert 32<=size<=128
  u.mem_write(COPIED,bytes(u.mem_read(x[1],size)))
  queued.append(struct.unpack('<Q',u.mem_read(COPIED+16,8))[0]);ret(0)
 elif name in ['_objc_retain','_objc_retainAutoreleasedReturnValue','_objc_retainBlock','_objc_autoreleaseReturnValue']:ret(x[0])
 elif name=='_objc_autoreleasePoolPush':ret(0x105000)
 elif name in ['_objc_release','_objc_autoreleasePoolPop']:ret(0)
 else:raise AssertionError(('stub',name))
u.hook_add(UC_HOOK_CODE,hook)
def run(va,args):
 u.reg_write(UC_ARM64_REG_SP,0x20fff0);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip(regs,args):u.reg_write(r,v)
 u.emu_start(va,STOP,count=10000)
 assert u.reg_read(UC_ARM64_REG_PC)==STOP and u.reg_read(UC_ARM64_REG_SP)==0x20fff0
for kind in ['Pair','Triple']:
 queued.clear();events.clear();copied=0
 run(symbols['_VVCloudFail'+kind],[0,0x4444,0,0]);assert not queued and not events and copied==0
 run(symbols['_VVCloudFail'+kind],[0,0x4444,BLOCK,0]);assert len(queued)==1 and not events and copied==1
 run(queued[0],[COPIED,0,0,0]);assert len(events)==1
 assert events[0][:4]==('callback',BLOCK,0,ERROR) if kind=='Pair' else events[0]==('callback',BLOCK,0,0,ERROR)
print('PASS: actual compiled pair/triple helpers ignore nil completion, copy the callback, enqueue without invoking it synchronously, then invoke exactly once with nil results and a nonnil NSError; stack is balanced.')
print('LIMIT: dispatch copying, Objective-C objects, ARC and autorelease pools are mocked; not an iOS integration test.')
