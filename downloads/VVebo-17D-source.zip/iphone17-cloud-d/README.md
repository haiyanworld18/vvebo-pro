# VVebo 17D cloud compatibility experiment

Baseline: verified 15A SHA256 46c2c14389780a5a7743b435439b58e5ebe3d3c4e1bf6552b490b49ee84224b6.
Target: iPhone 17 Pro Max / iOS 26, user re-signing in 全能签. NOT device-verified.

C's report identifies build 4.1703 and an uncaught CloudKit exception from main-view loading, at app offsets 0x305ae4 -> 0x27d808 -> 0x27c8d8. The earlier account-query call sites are no longer in this fatal trace. Do not infer a certificate failure or blame the network rewrite from this trace.

D starts from A. It retains B's six nil container results, restores C's two skipped callers, and disables the app's explicit query/modify operation creation paths. It replaces 20 direct operation allocations with nil and routes 3 Swift constructors through a gate that releases both consumed optional Swift arrays and returns nil. One save has no completion handler. All 22 explicit query/modify completion setters instead schedule the original completion block with nil results and an ordinary NSError. This is failure handling, never a forged purchase/authorization success.

The new helper object is linked with the exact original A networking object; no new custom Objective-C classes or CloudKit calls. The original application's handlers will process the error, which may affect its cloud-related UI/state. This patch does not explicitly erase local accounts or data, but full application behavior is not proven. iCloud cloud sync/account cloud metadata functions remain unavailable. Other CloudKit object types and calls still exist in the application; this is not a claim of complete CloudKit removal.

The main gate code occupies previously zero header padding at file offset 0x3400, below the original text start 0x66d8. The existing executable __text section is extended backward without changing its end or section ordinal. dlsym resolves exported pair/triple helpers via the existing libSystem stub. Failure to resolve returns without calling the completion. The standard ARM64 frame and callee-saved registers are preserved. Full device signing-tool preservation of this code region still needs testing.

Build prerequisites: Python 3 + capstone, Zig 0.13 C compiler, LLVM 19 ld64.lld; no proprietary SDK required. Set ZIG_BIN and LD64_LLD_BIN if needed. Keep sibling ios15-profile-a with its unchanged VVProfile15.o (included) and sources. Pass the verified public A IPA:

    python build_d.py /path/to/A.ipa
    python make_d.py /path/to/A.ipa /path/to/output
    python verify_d.py /path/to/A.ipa /path/to/output/VVebo-3.3.31-iPhone17-CloudCompat-D.ipa

With Python unicorn installed:

    python test_gates_arm64.py /path/to/D.ipa
    python test_failure_arm64.py VVProfile15
    python ../ios15-profile-a/test-registration-arm64.py VVProfile15
    python test_cloud_arm64.py /path/to/A.ipa /path/to/D.ipa

Offline checks execute actual compiled ARM64 gates and new failure-helper/queued-block code, with dispatch/Foundation/ARC/Swift reference functions mocked. They check nil completion, deferred callback execution and argument layout, stack/register preservation, consumed constructor arguments, and captured prior network IMP registration. Static checks validate exactly five changed files, 51 replaced instructions, gate bounds, restored C callers, entitlements, code/resource hashes and framework segment alignment. These are NOT full iOS integration, user-account, signing trust, login/relaunch, live network, or display tests. No display adaptation is included in D.

Do not publish raw crash reports, signed user IPAs, profiles, certificates or device identifiers.
