#import "AppleTypes.h"
@interface NSError : NSObject
+ (NSError*)errorWithDomain:(NSString*)domain code:(NSInteger)code userInfo:(NSDictionary*)info;
@end
extern void *dispatch_get_global_queue(long priority,unsigned long flags);
extern void dispatch_async(void *queue,void (^block)(void));

// No CloudKit objects are created here. The existing application's completion
// handlers receive an ordinary, permanent local error on a background queue.
static NSError *Unavailable(void) {
    return [NSError errorWithDomain:@"VVebo.CloudDisabled" code:1
        userInfo:@{@"NSLocalizedDescription":@"此兼容版已关闭 iCloud 云功能。"}];
}
__attribute__((visibility("default"),used))
void VVCloudFailPair(id operation,SEL selector,id completion) {
    (void)operation;(void)selector;
    if(!completion) return;
    id copied=[completion copy];
    dispatch_async(dispatch_get_global_queue(0,0), ^{
        @autoreleasepool {
            ((void(^)(id,NSError*))copied)(nil,Unavailable());
        }
    });
}
__attribute__((visibility("default"),used))
void VVCloudFailTriple(id operation,SEL selector,id completion) {
    (void)operation;(void)selector;
    if(!completion) return;
    id copied=[completion copy];
    dispatch_async(dispatch_get_global_queue(0,0), ^{
        @autoreleasepool {
            ((void(^)(id,id,NSError*))copied)(nil,nil,Unavailable());
        }
    });
}
