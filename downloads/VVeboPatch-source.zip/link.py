import sys,pathlib,subprocess,os
sys.path.insert(0,'/workspace/vvebo-analysis/build-tools')
import lief
root=pathlib.Path('/workspace/vvebo-analysis/patch');stubs=root/'stubs'
b=lief.MachO.parse(str(root/'VVeboPatch.o'))[0]
groups={'Foundation':[],'UIKit':[],'CoreFoundation':[],'objc':[],'System':[]}
for s in b.symbols:
 if s.type!=lief.MachO.Symbol.TYPE.UNDEFINED:continue
 n=s.name
 if n=='_OBJC_CLASS_$_UIWindow':lib='UIKit'
 elif n.startswith(('_OBJC_CLASS_$_NS','_OBJC_METACLASS_$_NS')) or n=='_NSLog':lib='Foundation'
 elif n=='___CFConstantStringClassReference':lib='CoreFoundation'
 elif n.startswith(('_objc_','__objc_','_class_','_method_','_object_','_sel_','___objc_')):lib='objc'
 else:lib='System'
 groups[lib].append(n)
for lib,symbols in groups.items():
 install='/usr/lib/lib'+lib+('.A.dylib' if lib=='objc' else '.B.dylib') if lib in ['objc','System'] else f'/System/Library/Frameworks/{lib}.framework/{lib}'
 name='lib'+lib+'.tbd'
 s='--- !tapi-tbd\ntbd-version: 4\ntargets: [ arm64-ios ]\ninstall-name: '+repr(install)+'\ncurrent-version: 1\ncompatibility-version: 1\nexports:\n  - targets: [ arm64-ios ]\n    symbols: [ '+', '.join(repr(n) for n in symbols)+' ]\n...\n'
 (stubs/name).write_text(s)
env=os.environ.copy();env.update(ZIG_GLOBAL_CACHE_DIR='/workspace/vvebo-analysis/zig-cache',ZIG_LOCAL_CACHE_DIR='/workspace/vvebo-analysis/zig-local-cache')
cmd=['/workspace/vvebo-analysis/build-tools/ziglang/zig','cc','-target','aarch64-ios.14.0','-dynamiclib','-nostdlib','-L'+str(stubs),'-Wl,-install_name,@rpath/VVeboPatch.dylib,-dead_strip,-headerpad,0x1000','-o',str(root/'VVeboPatch.dylib'),str(root/'VVeboPatch.o')]+[str(stubs/('lib'+lib+'.tbd')) for lib in groups if lib!='System']
subprocess.run(cmd,env=env,check=True)
print('Linked patch:',root/'VVeboPatch.dylib')
