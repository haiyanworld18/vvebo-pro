#import "AppleTypes.h"

// The network transformation follows the user-supplied bin64 Quantumult X script.
// It runs locally inside this application and adds no proxy or external service.
static NSString *latestUID;
static char kTaskState,kMethodTask,kMethodCompletion,kMethodFactory,kMethodData,kMethodDone,kMethodLayout;
@interface VVFixIMP:NSObject { @public IMP pointer; }
@end
@implementation VVFixIMP
@end
@interface VVFixState:NSObject
@property(strong) NSMutableData *data;
@end
@implementation VVFixState
@end

static IMP Original(id object,const void *key) {
    for(Class c=object_getClass(object);c;c=class_getSuperclass(c)) {
        VVFixIMP *entry=objc_getAssociatedObject((id)c,key);
        if(entry) return entry->pointer;
    }
    return (IMP)0;
}
static void Hook(Class cls,const char *name,IMP replacement,const void *key) {
    if(!cls) return;
    @synchronized([VVFixIMP class]) {
        SEL sel=sel_registerName(name);
        Method m=class_getInstanceMethod(cls,sel);
        if(!m || method_getImplementation(m)==replacement) return;
        VVFixIMP *saved=[VVFixIMP new]; saved->pointer=method_getImplementation(m);
        objc_setAssociatedObject((id)cls,key,saved,1);
        const char *types=method_getTypeEncoding(m);
        if(!class_addMethod(cls,sel,replacement,types)) class_replaceMethod(cls,sel,replacement,types);
    }
}
static BOOL IsWeibo(NSURL *url) {
    return [url.scheme isEqualToString:@"https"] && [url.host isEqualToString:@"api.weibo.cn"];
}
static BOOL NumericUID(NSString *uid) {
    // Existing requests carry numeric IDs. Empty or unexpected types are not rewritten.
    return [uid isKindOfClass:[NSString class]] && [uid integerValue]>0;
}
static NSURLRequest *Rewrite(NSURLRequest *request,BOOL *changed) {
    *changed=NO;
    NSURL *url=request.URL;
    if(!IsWeibo(url)) return request;
    BOOL isUser=[url.path isEqualToString:@"/2/users/show"];
    BOOL isTimeline=[url.path isEqualToString:@"/2/statuses/user_timeline"];
    if(!isUser && !isTimeline) return request;
    NSURLComponents *parts=[NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:NO];
    NSString *uid=nil;
    for(NSUInteger i=0;i<parts.queryItems.count;i++) {
        NSURLQueryItem *q=[parts.queryItems objectAtIndex:i];
        if([q.name isEqualToString:@"uid"] && NumericUID(q.value)) uid=q.value;
    }
    @synchronized([VVFixState class]) {
        if(uid) latestUID=[uid copy];
        else if(isTimeline) uid=latestUID;
    }
    if(!isTimeline || !uid) return request;
    NSMutableArray *items=[NSMutableArray array];
    for(NSUInteger i=0;i<parts.queryItems.count;i++) {
        NSURLQueryItem *q=[parts.queryItems objectAtIndex:i];
        if([q.name isEqualToString:@"containerid"]) continue;
        if([q.name isEqualToString:@"max_id"]) q=[NSURLQueryItem queryItemWithName:@"since_id" value:q.value];
        [items addObject:q];
    }
    [items addObject:[NSURLQueryItem queryItemWithName:@"containerid" value:[NSString stringWithFormat:@"230413%@_-_WEIBO_SECOND_PROFILE_WEIBO",uid]]];
    parts.path=@"/2/profile/statuses/tab";
    parts.queryItems=items;
    if(!parts.URL) return request;
    NSMutableURLRequest *copy=[request mutableCopy]; copy.URL=parts.URL;
    *changed=YES; return copy;
}
static NSData *Convert(NSData *input,NSURLResponse *response,NSError *error) {
    if(error || !input.length) return input;
    if([response isKindOfClass:[NSHTTPURLResponse class]]) {
        NSInteger status=((NSHTTPURLResponse*)response).statusCode;
        if(status<200 || status>=300) return input;
    }
    NSError *jsonError=nil;
    id root=[NSJSONSerialization JSONObjectWithData:input options:0 error:&jsonError];
    if(jsonError || ![root isKindOfClass:[NSDictionary class]]) return input;
    id cards=[root objectForKey:@"cards"];
    if(![cards isKindOfClass:[NSArray class]]) return input;
    NSMutableArray *statuses=[NSMutableArray array];
    for(NSUInteger i=0;i<[cards count];i++) {
        id card=[cards objectAtIndex:i];
        if(![card isKindOfClass:[NSDictionary class]]) continue;
        id group=[card objectForKey:@"card_group"];
        NSArray *entries=[group isKindOfClass:[NSArray class]] ? group : @[card];
        for(NSUInteger j=0;j<entries.count;j++) {
            id entry=[entries objectAtIndex:j];
            if(![entry isKindOfClass:[NSDictionary class]]) continue;
            id type=[entry objectForKey:@"card_type"];
            if(![type respondsToSelector:sel_registerName("integerValue")] || [type integerValue]!=9) continue;
            id post=[entry objectForKey:@"mblog"];
            if(![post isKindOfClass:[NSDictionary class]]) continue;
            id top=[post objectForKey:@"isTop"];
            if([top respondsToSelector:sel_registerName("boolValue")] && [top boolValue]) {
                NSMutableDictionary *p=[post mutableCopy]; p[@"label"]=@"置顶"; post=p;
            }
            [statuses addObject:post];
        }
    }
    NSMutableDictionary *result=[NSMutableDictionary dictionary];
    result[@"statuses"]=statuses; result[@"total_number"]=@100;
    id info=[root objectForKey:@"cardlistInfo"];
    if([info isKindOfClass:[NSDictionary class]]) {
        id since=[info objectForKey:@"since_id"];
        if(since) result[@"since_id"]=since;
    }
    NSData *output=[NSJSONSerialization dataWithJSONObject:result options:0 error:&jsonError];
    return output && !jsonError ? output : input;
}
static void Receive(id self,SEL cmd,id session,NSURLSessionTask *task,NSData *data) {
    VVFixState *state=objc_getAssociatedObject(task,&kTaskState);
    if(state) { @synchronized(state) { [state.data appendData:data]; } return; }
    ((void(*)(id,SEL,id,id,id))Original(self,&kMethodData))(self,cmd,session,task,data);
}
static void Complete(id self,SEL cmd,id session,NSURLSessionTask *task,NSError *error) {
    VVFixState *state=objc_getAssociatedObject(task,&kTaskState);
    if(state) {
        NSData *data;
        @synchronized(state) { data=[state.data copy]; }
        objc_setAssociatedObject(task,&kTaskState,nil,1);
        if(data.length) {
            NSData *converted=Convert(data,task.response,error);
            ((void(*)(id,SEL,id,id,id))Original(self,&kMethodData))(self,sel_registerName("URLSession:dataTask:didReceiveData:"),session,task,converted);
        }
    }
    ((void(*)(id,SEL,id,id,id))Original(self,&kMethodDone))(self,cmd,session,task,error);
}
static BOOL CanBuffer(id delegate) {
    return class_getInstanceMethod(object_getClass(delegate),sel_registerName("URLSession:dataTask:didReceiveData:")) && class_getInstanceMethod(object_getClass(delegate),sel_registerName("URLSession:task:didCompleteWithError:"));
}
static void InstallDelegate(id delegate) {
    if(!CanBuffer(delegate)) return;
    Hook(object_getClass(delegate),"URLSession:dataTask:didReceiveData:",(IMP)Receive,&kMethodData);
    Hook(object_getClass(delegate),"URLSession:task:didCompleteWithError:",(IMP)Complete,&kMethodDone);
}
@interface NSURLSession (VVFixDelegate)
@property(readonly) id delegate;
@end
static id DataTask(id self,SEL cmd,NSURLRequest *request) {
    BOOL changed=NO;
    // Delegate-driven sessions must support both callbacks for safe response conversion.
    NSURLRequest *updated=CanBuffer([self delegate]) ? Rewrite(request,&changed) : request;
    id task=((id(*)(id,SEL,id))Original(self,&kMethodTask))(self,cmd,updated);
    if(changed && task) {
        VVFixState *state=[VVFixState new];state.data=[NSMutableData data];
        objc_setAssociatedObject(task,&kTaskState,state,1);
    }
    return task;
}
typedef void(^VVCompletion)(NSData*,NSURLResponse*,NSError*);
static id DataTaskCompletion(id self,SEL cmd,NSURLRequest *request,VVCompletion completion) {
    BOOL changed=NO; NSURLRequest *updated=Rewrite(request,&changed);
    VVCompletion wrapped=completion;
    if(changed && completion) {
        wrapped=^(NSData *data,NSURLResponse *response,NSError *error) { completion(Convert(data,response,error),response,error); };
    }
    return ((id(*)(id,SEL,id,VVCompletion))Original(self,&kMethodCompletion))(self,cmd,updated,wrapped);
}
static void InstallSession(id session) {
    if(!session) return;
    InstallDelegate([session delegate]);
    Hook(object_getClass(session),"dataTaskWithRequest:",(IMP)DataTask,&kMethodTask);
    Hook(object_getClass(session),"dataTaskWithRequest:completionHandler:",(IMP)DataTaskCompletion,&kMethodCompletion);
}
static id Factory(id self,SEL cmd,id configuration,id delegate,id queue) {
    InstallDelegate(delegate);
    id session=((id(*)(id,SEL,id,id,id))Original(self,&kMethodFactory))(self,cmd,configuration,delegate,queue);
    InstallSession(session);return session;
}
// Optional scene-fill experiment. Does not invent a physical resolution or alter safe areas.
static BOOL inWindowLayout;
static void Layout(id self,SEL cmd) {
    ((void(*)(id,SEL))Original(self,&kMethodLayout))(self,cmd);
    if(inWindowLayout) return;
    UIWindow *window=self;
    if(window.windowLevel!=0 || !window.rootViewController || !window.windowScene) return;
    CGRect desired=window.windowScene.coordinateSpace.bounds;
    CGRect actual=window.frame;
    if(desired.size.width<=0 || desired.size.height<=0) return;
    double dx=actual.origin.x-desired.origin.x,dy=actual.origin.y-desired.origin.y;
    double dw=actual.size.width-desired.size.width,dh=actual.size.height-desired.size.height;
    if(dx*dx+dy*dy+dw*dw+dh*dh<0.25) return;
    inWindowLayout=YES; window.frame=desired; inWindowLayout=NO;
}
__attribute__((constructor)) static void VVFixStart(void) {
    @autoreleasepool {
        if(![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.johnil.vvebo"]) return;
        Hook(object_getClass((id)[NSURLSession class]),"sessionWithConfiguration:delegate:delegateQueue:",(IMP)Factory,&kMethodFactory);
        if([[[NSBundle mainBundle] objectForInfoDictionaryKey:@"VVFixSceneFill"] boolValue]) {
            Hook([UIWindow class],"layoutSubviews",(IMP)Layout,&kMethodLayout);
        }
        NSLog(@"[VVeboPatch] Local profile adapter loaded; scene-fill follows VVFixSceneFill.");
    }
}
