import zipfile,struct,hashlib,plistlib,pathlib,sys
sys.path.insert(0,'/workspace/vvebo-analysis/build-tools')
import lief
SOURCE=pathlib.Path('/workspace/attachments/13f0b5c6-0601-438c-bcc6-123d94ddb42a/VVebo砸壳_3.3.31_纯净无弹窗.ipa')
APP='Payload/VVebo.app/'
def cmds(b):
 p=32
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  c,s=struct.unpack_from('<II',b,p);assert s>=8 and s%8==0;yield p,c,s;p+=s
 assert p==32+struct.unpack_from('<I',b,20)[0]
def signature(b,info=None,resources=None):
 p=next(p for p,c,s in cmds(b) if c==0x1d)
 off,size=struct.unpack_from('<II',b,p+8);assert off+size==len(b)
 magic,length,n=struct.unpack_from('>III',b,off);assert magic==0xfade0cc0 and length==size
 blobs={}
 for i in range(n):
  k,r=struct.unpack_from('>II',b,off+12+8*i);ln=struct.unpack_from('>I',b,off+r+4)[0];blobs[k]=b[off+r:off+r+ln]
 cd=blobs[0]
 magic,ln,version,flags,ho,ident,ns,nc,limit=struct.unpack_from('>9I',cd)
 assert magic==0xfade0c02 and flags&2 and len(cd)==ln and limit==off
 assert cd[36:40]==bytes([32,2,0,12]);assert nc==(limit+4095)//4096
 for i in range(nc):assert cd[ho+32*i:ho+32*(i+1)]==hashlib.sha256(b[i*4096:min(limit,4096*(i+1))]).digest(),('page',i)
 special={}
 if info is not None:special[1]=info
 if resources is not None:special[3]=resources
 special.update({k:v for k,v in blobs.items() if k in [5,7]})
 for k,v in special.items():assert cd[ho-32*k:ho-32*(k-1)]==hashlib.sha256(v).digest(),('special slot',k)
 return blobs,hashlib.sha256(cd).digest()[:20]
def section_bytes(b,name):
 for p,c,s in cmds(b):
  if c!=0x19:continue
  count=struct.unpack_from('<I',b,p+64)[0]
  for i in range(count):
   q=p+72+i*80
   if b[q:q+16].split(b'\0')[0]==name:
    size,offset=struct.unpack_from('<QI',b,q+40);return b[offset:offset+size]
 raise AssertionError(name)
with zipfile.ZipFile(SOURCE) as z:original={n:z.read(n) for n in z.namelist()}
old=original[APP+'VVebo']
p=next(p for p,c,s in cmds(old) if c==0x1d)
off=struct.unpack_from('<I',old,p+8)[0];n=struct.unpack_from('>I',old,off+8)[0]
original_entitlements={}
for i in range(n):
 k,r=struct.unpack_from('>II',old,off+12+8*i);ln=struct.unpack_from('>I',old,off+r+4)[0]
 original_entitlements[k]=old[off+r:off+r+ln]
allowed={APP+'Info.plist',APP+'VVebo',APP+'_CodeSignature/CodeResources',APP+'Frameworks/VVeboPatch.dylib'}
for path in sorted(pathlib.Path('/workspace/output').glob('*.ipa')):
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  files={n:z.read(n) for n in z.namelist()}
  assert set(files)==set(original)|{APP+'Frameworks/VVeboPatch.dylib'}
  changed={n for n in files if n not in original or files[n]!=original[n]};assert changed==allowed
  info=plistlib.loads(files[APP+'Info.plist'])
  assert info['CFBundleIdentifier']=='com.johnil.vvebo' and info['VVFixPatchVersion']=='1.0-test'
  assert info['VVFixSceneFill']==('SceneFill' in path.name)
  main=files[APP+'VVebo'];patch=files[APP+'Frameworks/VVeboPatch.dylib'];resources=files[APP+'_CodeSignature/CodeResources']
  assert section_bytes(main,b'__text')==section_bytes(original[APP+'VVebo'],b'__text')
  sig,_=signature(main,files[APP+'Info.plist'],resources)
  for slot in [5,7]:assert sig.get(slot)==original_entitlements.get(slot)
  _,cdhash=signature(patch)
  seals=plistlib.loads(resources)
  assert seals['files2']['Frameworks/VVeboPatch.dylib']['cdhash']==cdhash
  legacy=seals['files'].get('Info.plist')
  if legacy is not None:
   assert (legacy.get('hash') if isinstance(legacy,dict) else legacy)==hashlib.sha1(files[APP+'Info.plist']).digest()
  libs=[]
  for p,c,s in cmds(main):
   if c==0xc:
    at=struct.unpack_from('<I',main,p+8)[0];libs.append(main[p+at:p+s].split(b'\0')[0])
  assert libs.count(b'@executable_path/Frameworks/VVeboPatch.dylib')==1
  parsed=lief.MachO.parse(list(patch))[0]
  assert parsed.header.cpu_type==lief.MachO.Header.CPU_TYPE.ARM64
  assert len(section_bytes(patch,b'__mod_init_func'))>=8
  assert len(list(parsed.imported_symbols))>0
  for symbol in parsed.imported_symbols:
   if symbol.raw_type & 0xe0 or symbol.type!=lief.MachO.Symbol.TYPE.UNDEFINED:continue
   ordinal=(symbol.description>>8)&255
   assert 1<=ordinal<=5,('unbound or dynamic-lookup import',symbol.name,ordinal)
 print('PASS',path.name,': ZIP CRC, exact resource changes, original application code/entitlements, all SHA-256 code pages and special slots, dylib load command, ARM64 initializer, dependency bindings.')
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='6e497fb4c6e264e66b05a3289f1eed9958a0cea7792fbaf00e1484fcd31e4ed5'
print('PASS: Original uploaded IPA is unchanged. No on-device execution or production signing verified.')
