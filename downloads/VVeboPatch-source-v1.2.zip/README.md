# VVebo patch v1.2 sources

Experimental local profile-response adapter. On-device acceptance and execution are not verified.

Requires Zig 0.13.0 (C/Objective-C compilation), LLVM ld64.lld 19.1.7, Python 3, and Python package lief for validation. The .tbd files contain only public symbol declarations; implementations are provided by iOS. System-library choices were checked against the original application/framework imports.

Run from this directory:

    ZIG_BIN=/path/to/zig LD64_LLD_BIN=/path/to/ld64.lld bash build.sh /path/to/original.ipa /path/to/output

The input is the original uploaded IPA, not a previously patched or user-signed build. The output retains the original application ID, uses build 4.12, and has only temporary build-stage signatures; it must be signed by a supported user installation tool. No certificate or credential is included.

The reference algorithm is the user-provided bin64 QX script:
https://raw.githubusercontent.com/bin64/Scripts/main/QuantumultX/vvebo.js

The patch rewrites the profile request and adapts card responses. Scene-fill is disabled in v1.2. No new network destination, credential logging, or external proxy is introduced. Checks in verify-framework.py validate structure and hashes, not actual iOS runtime behavior.
