from pathlib import Path
import struct,zipfile,hashlib,plistlib,json,sys
import lief
from validation_helpers import cmds,signature,section_bytes
from macho_imports import imports
if len(sys.argv)!=3:raise SystemExit('Usage: verify-framework.py ORIGINAL_IPA PATCHED_IPA')
SOURCE=Path(sys.argv[1]);p=Path(sys.argv[2]);APP='Payload/VVebo.app/'
with zipfile.ZipFile(SOURCE) as z:original={n:z.read(n) for n in z.namelist()}
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None;files={n:z.read(n) for n in z.namelist()}
 framework='Frameworks/VVeboPatch.framework/'
 allowed={APP+'VVebo',APP+'Info.plist',APP+'_CodeSignature/CodeResources',APP+framework+'VVeboPatch',APP+framework+'Info.plist'}
 changed={n for n in files if n not in original or files[n]!=original[n]};assert changed==allowed
 assert set(files)==set(original)|{APP+framework+'VVeboPatch',APP+framework+'Info.plist'}
 assert not any(n.endswith('VVeboPatch.dylib') for n in files)
 info=plistlib.loads(files[APP+'Info.plist']);fwinfo=plistlib.loads(files[APP+framework+'Info.plist'])
 assert info['VVFixPatchVersion']=='1.2-framework-test' and info['CFBundleVersion']=='4.12' and info['VVFixSceneFill'] is False
 assert fwinfo['CFBundleExecutable']=='VVeboPatch' and fwinfo['CFBundlePackageType']=='FMWK'
 main=files[APP+'VVebo'];patch=files[APP+framework+'VVeboPatch'];resources=files[APP+'_CodeSignature/CodeResources']
 assert section_bytes(main,b'__text')==section_bytes(original[APP+'VVebo'],b'__text')
 signature(main,files[APP+'Info.plist'],resources)
 _,cdhash=signature(patch)
 seals=plistlib.loads(resources);assert seals['files2']['Frameworks/VVeboPatch.framework']['cdhash']==cdhash
 for rel in [framework+'Info.plist',framework+'VVeboPatch']:
  assert seals['files'][rel]==hashlib.sha1(files[APP+rel]).digest()
 legacy=seals['files']['Info.plist'];assert (legacy.get('hash') if isinstance(legacy,dict) else legacy)==hashlib.sha1(files[APP+'Info.plist']).digest()
 loads=[]
 for q,c,s in cmds(main):
  if c==0xc:
   at=struct.unpack_from('<I',main,q+8)[0];loads.append(main[q+at:q+s].split(b'\0')[0])
 assert loads.count(b'@executable_path/Frameworks/VVeboPatch.framework/VVeboPatch')==1
 # Non-LINKEDIT file-backed segments are aligned to iOS arm64 16 KiB pages.
 for q,c,s in cmds(patch):
  if c==0x19:
   name=patch[q+8:q+24].split(b'\0')[0];vm,vs,off,fs=struct.unpack_from('<4Q',patch,q+24)
   assert vm%16384==0 and off%16384==0
   if name!=b'__LINKEDIT':assert vs%16384==0 and fs%16384==0
 parsed=lief.MachO.parse(list(patch))[0]
 init=section_bytes(patch,b'__init_offsets')
 assert len(init)>=4 and len(init)%4==0
 text_section=next(s for s in parsed.sections if s.name=='__text')
 for i in range(0,len(init),4):
  entry=struct.unpack_from('<I',init,i)[0]
  assert text_section.virtual_address<=entry<text_section.virtual_address+text_section.size
 assert parsed.has_code_signature
 providers=json.loads((Path(__file__).resolve().parent/'import-providers.json').read_text())
 for name,provider in imports(patch).items():assert providers[name]==provider,(name,provider)
 print('PASS: ZIP, exact changed-file set, original instruction code, framework metadata, unique build number, scene-fill disabled, main and LLVM-generated library code signatures, resource seals, framework load path, 16-KiB segment layout, initializer and verified system import providers.')
 print('NOT VERIFIED: signing by user tool, device signature acceptance, launch, live profile API, pagination and black bars.')
