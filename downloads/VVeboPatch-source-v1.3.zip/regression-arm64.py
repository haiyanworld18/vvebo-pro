"""Run the compiled Hook function in ARM64 emulation with mocked OS APIs.
This narrowly checks the object-header corruption from the real v1.2 crash.
It does not emulate Foundation, dyld, code signing, or the full application.
"""
import struct,sys,json
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3,UC_ARM64_REG_LR,UC_ARM64_REG_PC,UC_ARM64_REG_SP

def parse(b):
 p=32;segs=[];syms=None;ind=None;stubsec=None;selectors=[]
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  c,s=struct.unpack_from('<II',b,p)
  if c==2:syms=struct.unpack_from('<4I',b,p+8)
  if c==0xb:ind=struct.unpack_from('<II',b,p+56)
  if c==0x19:
   vm,vs,fo,fs=struct.unpack_from('<4Q',b,p+24);segs.append((vm,vs,fo,fs))
   for i in range(struct.unpack_from('<I',b,p+64)[0]):
    q=p+72+80*i
    if b[q:q+16].split(b'\0')[0]==b'__objc_selrefs':
     va,size,fo=struct.unpack_from('<QQI',b,q+32)
     for j in range(0,size,8):selectors.append((va+j,struct.unpack_from('<Q',b,fo+j)[0]&0xfffffffff))
    if b[q:q+16].split(b'\0')[0]==b'__stubs':
     va,size=struct.unpack_from('<QQ',b,q+32);first,entrysize=struct.unpack_from('<II',b,q+68);stubsec=(va,size,first,entrysize)
  p+=s
 so,n,st,ss=syms;symbols=[];addresses={}
 for i in range(n):
  no,t,se,d,v=struct.unpack_from('<IBBHQ',b,so+16*i);name=b[st+no:st+ss].split(b'\0')[0].decode();symbols.append(name)
  if not t&0xe0 and t&0xe==0xe:addresses[name]=v
 va,size,first,entrysize=stubsec;io,ic=ind;stubs={}
 for i in range(size//entrysize):
  si=struct.unpack_from('<I',b,io+4*(first+i))[0];stubs[va+entrysize*i]=symbols[si]
 return segs,addresses,stubs,selectors

def exercise(path):
 b=Path(path).read_bytes();segs,symbols,stubs,selectors=parse(b)
 uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM);uc.mem_map(0,0x40000);uc.mem_map(0x100000,0x20000);uc.mem_map(0x200000,0x10000);uc.mem_map(0x300000,0x1000)
 for vm,vs,fo,fs in segs:
  if fs:uc.mem_write(vm,b[fo:fo+fs])
 for address,target in selectors:uc.mem_write(address,struct.pack('<Q',target))
 OBJ=0x102000;CLASS=0x10e000;METHOD=0x103000;IMP=0x104000;REPLACEMENT=0x104200;STOP=0x300000
 uc.mem_write(OBJ,struct.pack('<QQ',CLASS,0));uc.mem_write(0x107000,b'dataTaskWithRequest:\0');uc.mem_write(0x107100,b'@@:@\0')
 if '_patchLock' in symbols:uc.mem_write(symbols['_patchLock'],struct.pack('<Q',CLASS))
 uc.reg_write(UC_ARM64_REG_SP,0x20fff0);uc.reg_write(UC_ARM64_REG_LR,STOP)
 for reg,value in [(UC_ARM64_REG_X0,CLASS),(UC_ARM64_REG_X1,0x107000),(UC_ARM64_REG_X2,REPLACEMENT),(UC_ARM64_REG_X3,0x108000)]:uc.reg_write(reg,value)
 result={'calls':[]}
 def cstr(p):
  chars=[]
  for _ in range(200):
   x=bytes(uc.mem_read(p,1));p+=1
   if x==b'\0':break
   chars.append(x)
  return b''.join(chars).decode()
 def call(uc,address,size,data):
  name=stubs.get(address)
  if not name:return
  result['calls'].append(name);x0=uc.reg_read(UC_ARM64_REG_X0)
  if name=='_objc_msgSend':
   selector=cstr(uc.reg_read(UC_ARM64_REG_X1));result['calls'].append(selector)
   if selector=='class':ret=CLASS
   elif selector=='new':ret=OBJ
   elif selector=='valueWithPointer:':
    value=uc.reg_read(UC_ARM64_REG_X2);assert value==IMP
    uc.mem_write(OBJ+8,struct.pack('<Q',value));ret=OBJ
   else:raise AssertionError(('unexpected selector',selector))
  elif name=='_class_getInstanceMethod':ret=METHOD
  elif name=='_method_getImplementation':ret=IMP
  elif name=='_method_getTypeEncoding':ret=0x107100
  elif name=='_class_addMethod':ret=1
  elif name=='_sel_registerName':ret=x0
  elif name=='_objc_setAssociatedObject':
   value=uc.reg_read(UC_ARM64_REG_X2);assert value==OBJ
   result['object_header']=struct.unpack('<Q',uc.mem_read(OBJ,8))[0]
   result['boxed_pointer']=struct.unpack('<Q',uc.mem_read(OBJ+8,8))[0];ret=0
  elif name in ['_objc_sync_enter','_objc_sync_exit','_objc_release']:ret=0
  elif name in ['_objc_retainAutoreleasedReturnValue','_objc_retain','_objc_autoreleaseReturnValue']:ret=x0
  else:raise AssertionError(('unexpected OS call',name))
  uc.reg_write(UC_ARM64_REG_X0,ret);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))
 uc.hook_add(UC_HOOK_CODE,call);uc.emu_start(symbols['_Hook'],STOP,count=10000)
 assert uc.reg_read(UC_ARM64_REG_PC)==STOP and 'object_header' in result
 result['header_preserved']=result['object_header']==CLASS
 result['pointer_saved']=result['boxed_pointer']==IMP
 return result

if len(sys.argv)!=3:raise SystemExit('Usage: regression-arm64.py V1_2_BINARY NEW_BINARY')
old=exercise(sys.argv[1]);new=exercise(sys.argv[2])
assert old['header_preserved'] is False,old
assert new['header_preserved'] is True and new['pointer_saved'] is True,new
print('PASS: v1.2 compiled Hook overwrites the object header with the original IMP (reproduces crash mechanism).')
print('PASS: corrected compiled Hook preserves the object header and stores the exact IMP via mocked NSValue API.')
print('LIMIT: ARM64 function-level test with OS calls mocked; no iOS signing or full-app execution tested.')
