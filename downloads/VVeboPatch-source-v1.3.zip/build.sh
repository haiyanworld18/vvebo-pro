#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ZIG_BIN:=zig}"
: "${LD64_LLD_BIN:=ld64.lld}"
: "${ZIG_GLOBAL_CACHE_DIR:=$PWD/.zig-global-cache}"
: "${ZIG_LOCAL_CACHE_DIR:=$PWD/.zig-local-cache}"
export ZIG_GLOBAL_CACHE_DIR ZIG_LOCAL_CACHE_DIR
"$ZIG_BIN" cc -target aarch64-ios.14.0 -fobjc-arc -fobjc-runtime=ios-14.0 -fblocks -O2 -g0 -Wall -Wextra -Werror -c VVeboPatch.m -o VVeboPatch.o
"$LD64_LLD_BIN" -dylib -arch arm64 -platform_version ios 14.0 15.5 -install_name @rpath/VVeboPatch.framework/VVeboPatch -current_version 1.3 -compatibility_version 1.0 -headerpad 0x1000 -dead_strip -adhoc_codesign -o VVeboPatch VVeboPatch.o stubs/libFoundation.tbd stubs/libUIKit.tbd stubs/libCoreFoundation.tbd stubs/libobjc.tbd stubs/libSystem.tbd
python package-framework.py "$1" "$2"
python verify-framework.py "$1" "$2/VVebo-3.3.31-ProfileFix-v1.3-Framework-Test.ipa"
