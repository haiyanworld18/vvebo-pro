import struct
def imports(b):
 if b[:4]!=b'\xcf\xfa\xed\xfe':return {}
 libs=[];p=32;symbols=None
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  c,s=struct.unpack_from('<II',b,p)
  if c in [0xc,0x80000018,0x8000001f,0x80000023]:
   n=struct.unpack_from('<I',b,p+8)[0];libs.append(b[p+n:p+s].split(b'\0')[0].decode())
  if c==2:symbols=struct.unpack_from('<4I',b,p+8)
  p+=s
 if not symbols:return {}
 so,n,st,sz=symbols;out={}
 for i in range(n):
  name,typ,sect,desc,val=struct.unpack_from('<IBBHQ',b,so+16*i)
  if typ&0xe0 or typ&0xe or not name:continue
  ord=desc>>8
  if 0<ord<=len(libs):out[b[st+name:st+sz].split(b'\0')[0].decode()]=libs[ord-1]
 return out