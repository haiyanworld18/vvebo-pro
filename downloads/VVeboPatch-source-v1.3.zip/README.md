# VVebo patch v1.3 sources

Fixes the object-header corruption in v1.2 Hook identified in the uploaded crash report. Custom Objective-C storage classes were removed; NSValue stores IMPs and NSMutableData directly buffers response bytes. No custom ivar writes remain.

Requires Zig 0.13.0, LLVM ld64.lld 19.1.7, Python 3, and lief for structure checks. Public-symbol .tbd declarations are included; actual system implementations come from iOS.

Build using the original uploaded IPA, not a signed or patched copy:

    ZIG_BIN=/path/to/zig LD64_LLD_BIN=/path/to/ld64.lld bash build.sh /path/to/original.ipa /path/to/output

The narrow instruction-level regression additionally requires Python package unicorn:

    python regression-arm64.py /path/to/v1.2/VVeboPatch ./VVeboPatch

It runs the actual compiled Hook from both binaries with mocked OS calls. The old image must overwrite the mocked object's header; the new image must preserve it and box the correct IMP. It does not simulate Foundation, dyld, signing, networking, or the complete app. These fixture images use chained 64-bit selector rebases, which the harness resolves for its test memory map.

On-device startup and live API behavior remain unverified. The output is build 4.13, display name VVebo 1.3, requires user signing, and has scene-fill disabled. No certificate or private signing material is included.

The profile transformation follows the user-provided bin64 QX script:
https://raw.githubusercontent.com/bin64/Scripts/main/QuantumultX/vvebo.js
