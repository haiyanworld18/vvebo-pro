from pathlib import Path
import sys,zipfile,plistlib,struct,hashlib
from macho_helpers import blobs
from validation_helpers import signature,cmds
APP='Payload/VVebo.app/'
base,target=map(Path,sys.argv[1:]);assert hashlib.sha256(base.read_bytes()).hexdigest()=='421cf67f08d72165b06b45d207f4c000b9db155c0ad66b1ba81cc423206ff71f'
with zipfile.ZipFile(base) as z:old={n:z.read(n) for n in z.namelist()}
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None;files={n:z.read(n) for n in z.namelist()}
assert set(files)==set(old)
assert {n for n in files if files[n]!=old[n]}=={APP+'VVebo',APP+'Info.plist',APP+'_CodeSignature/CodeResources'}
b=old[APP+'VVebo'];main=files[APP+'VVebo']
# Entire signed prefix, including code, load commands, SDK and section geometry.
oldcmd=next(p for p,c,s in cmds(b) if c==0x1d);newcmd=next(p for p,c,s in cmds(main) if c==0x1d)
oldoff,oldsize=struct.unpack_from('<II',b,oldcmd+8);newoff,newsize=struct.unpack_from('<II',main,newcmd+8)
assert oldoff==newoff and b[:oldoff]==main[:newoff],'Executable bytes must remain unchanged'
for k in [5,7]:assert blobs(main).get(k)==blobs(b).get(k)
info=plistlib.loads(files[APP+'Info.plist']);oi=plistlib.loads(old[APP+'Info.plist'])
assert info['CFBundleDisplayName']=='VVebo 17F' and info['CFBundleVersion']=='4.1706'
assert info['UILaunchScreen']=={} and 'UILaunchStoryboardName' not in info
assert oi['UILaunchStoryboardName']=='Launch Screen' and 'UILaunchScreen' not in oi
for k in ['CFBundleDisplayName','CFBundleVersion','UILaunchStoryboardName','UILaunchScreen','VVProfile17DisplayCompatibility']:info.pop(k,None);oi.pop(k,None)
assert info==oi,'No unrelated application settings changes'
res=plistlib.loads(files[APP+'_CodeSignature/CodeResources']);ores=plistlib.loads(old[APP+'_CodeSignature/CodeResources'])
for n,v in res['files'].items():
 if APP+n in files:assert (v['hash'] if isinstance(v,dict) else v)==hashlib.sha1(files[APP+n]).digest(),n
res['files'].pop('Info.plist');ores['files'].pop('Info.plist');assert res==ores
signature(main,files[APP+'Info.plist'],files[APP+'_CodeSignature/CodeResources'])
print('PASS: exact 3 changed files; whole main executable prefix, SDK, code and section layout unchanged; all frameworks/UI assets unchanged; exact launch-screen/build metadata scope; original cloud-disable/profile settings and entitlements preserved; ZIP, resource seals and SHA256 code signatures validated.')
print('LIMIT: UIKit launch-screen interpretation, window dimensions, removal of edge lines, signing trust and on-device launch require device testing.')
