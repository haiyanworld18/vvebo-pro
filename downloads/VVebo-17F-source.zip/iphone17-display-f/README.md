# VVebo 17F: launch-screen selection experiment

User confirmed E no longer crashes and profiles work, but thin lines remain along the top and bottom of the display. The cause is NOT established. This is a bounded display experiment, not a claim of full iPhone 17 resolution adaptation.

Baseline: user-confirmed E SHA256 421cf67f08d72165b06b45d207f4c000b9db155c0ad66b1ba81cc423206ff71f.

Original inspection: the main scene creates a standard UIWindow with initWithWindowScene:, and the app declares a compiled launch storyboard. F only replaces UILaunchStoryboardName with an empty UILaunchScreen dictionary, using the iOS 14+ system launch-screen mechanism with no optional image or named-color assets. This tests whether old launch-screen selection contributes to the display-area mismatch. It may not change the edge lines. The original storyboard resources are left intact.

Root display name VVebo 17F; build 4.1706. All executable bytes before the code signature are exactly equal to E, including linked SDK/build commands, section geometry, cloud boundary patches and original application code. Every framework and UI asset is exactly equal to E. No UIKit hooks, guessed physical resolution, window-frame setters, safe-area changes, SDK version edits, data clearing or new runtime helper code.

Python 3 standard library only:

    python make_f.py /path/to/E.ipa /path/to/output
    python verify_f.py /path/to/E.ipa /path/to/output/VVebo-3.3.31-iPhone17-Display-F.ipa

Static verification checks exact changed files/settings, whole executable signed prefix equality, framework/resource identity, original entitlements, ZIP integrity and code/resource hashes. There is no new executable code requiring ARM64 unit tests. UIKit interpretation, actual window/display bounds, edge-line removal, launch and signing trust require on-device testing.

Keep verified E as the stable baseline. Re-sign and cover-install F without uninstalling or clearing local data; the new build number distinguishes this installation. Cloud functions remain disabled and homepage patch remains the E version. No raw user logs, signed packages, certificates, profiles or device identifiers are included.
