"""Make launch-screen-only F experiment from user-confirmed E; no code hooks."""
from pathlib import Path
import zipfile,plistlib,hashlib,json,sys
from macho_helpers import sign
APP='Payload/VVebo.app/'
E_HASH='421cf67f08d72165b06b45d207f4c000b9db155c0ad66b1ba81cc423206ff71f'
base,out=map(Path,sys.argv[1:]);assert hashlib.sha256(base.read_bytes()).hexdigest()==E_HASH
out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(base) as z:files={i.filename:z.read(i.filename) for i in z.infolist()};metas={i.filename:i for i in z.infolist()}
info=plistlib.loads(files[APP+'Info.plist']);assert info['CFBundleVersion']=='4.1705';assert info['UILaunchStoryboardName']=='Launch Screen'
info.pop('UILaunchStoryboardName')
# Public iOS 14+ launch-screen declaration with no optional image/color assets.
# This experiment changes launch-screen selection, not the physical resolution,
# linked SDK, safe-area insets, window frames or ongoing application rendering.
info['UILaunchScreen']={}
info['CFBundleDisplayName']='VVebo 17F';info['CFBundleVersion']='4.1706'
info['VVProfile17DisplayCompatibility']='system-launch-screen-f'
files[APP+'Info.plist']=plistlib.dumps(info,fmt=plistlib.FMT_BINARY,sort_keys=False)
rp=APP+'_CodeSignature/CodeResources';res=plistlib.loads(files[rp]);old=res['files']['Info.plist'];digest=hashlib.sha1(files[APP+'Info.plist']).digest()
if isinstance(old,dict):old=dict(old);old['hash']=digest
else:old=digest
res['files']['Info.plist']=old;files[rp]=plistlib.dumps(res,fmt=plistlib.FMT_XML,sort_keys=True)
files[APP+'VVebo'],_=sign(bytearray(files[APP+'VVebo']),info['CFBundleIdentifier'],files[APP+'Info.plist'],files[rp])
target=out/'VVebo-3.3.31-iPhone17-Display-F.ipa'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,data in files.items():
  old=metas[n];zi=zipfile.ZipInfo(n,old.date_time);zi.external_attr=old.external_attr;zi.create_system=old.create_system;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,data)
manifest={'baseline':'User-confirmed E, unchanged executable code and network/cloud logic','baseline_sha256':E_HASH,'launch_screen_change':{'removed':{'UILaunchStoryboardName':'Launch Screen'},'added':{'UILaunchScreen':{}}},'build':'4.1706','status':'Unverified screen experiment; cause of thin edge bars not confirmed','sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(out/'iPhone17-F-change-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(target.name,target.stat().st_size,manifest['sha256'])
