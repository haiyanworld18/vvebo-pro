# VVProfile15 A

Restarted profile-only experiment for the user's verified baseline: iPhone 13 Pro Max, iOS 15, TrollStore. The original application SHA-256 is checked before packaging. No iOS runtime validation has yet passed for this new patch.

The prior custom method-address objects and dynamic receiver-class lookup were removed. Each method now uses a standard runtime implementation block capturing its previous IMP. A fixed, atomically guarded C registry tracks concrete class ownership and duplicate installation. No custom Objective-C classes or window hooks are defined.

Build dependencies: Zig 0.13.0 for Objective-C compilation, LLVM ld64.lld 19.1.7 for linking, Python 3 and lief for structural validation. Included .tbd files contain public symbol declarations only. A separately linked runtime block API is provided by iOS libobjc.

    ZIG_BIN=/path/to/zig LD64_LLD_BIN=/path/to/ld64.lld bash build.sh /path/to/original.ipa /path/to/output

Targeted machine-code registration checks additionally require Python package unicorn:

    python test-registration-arm64.py ./VVProfile15

This executes the actual compiled Install function. Objective-C runtime APIs and its builder block are mocked. It checks captured prior IMPs, duplicate installation, class ownership/inheritance, missing methods and bounded capacity. It does not execute Apple block trampolines, Foundation, signing, networking or app launch.

Output: VVebo-3.3.31-iOS15-Profile-A.ipa, display name VVebo 15A, build 4.1501. Use the original baseline IPA, not an earlier patched/signed file, as input. Root application instructions are retained; a new local framework is loaded. The package requires the intended on-device installation flow and preserves the original Bundle ID.

The mapping algorithm follows the user-provided working QX script:
https://raw.githubusercontent.com/bin64/Scripts/main/QuantumultX/vvebo.js

No credentials, private certificate material, original crash logs or user-signed IPAs are included.
