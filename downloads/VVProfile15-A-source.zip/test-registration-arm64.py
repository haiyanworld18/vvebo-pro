"""Execute the compiled iOS15 registration routine with mocked runtime APIs.
Tests class ownership, captured prior IMPs, repeated installation and capacity.
This does not execute the full Objective-C runtime or app.
"""
import struct,sys
from pathlib import Path
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3,UC_ARM64_REG_LR,UC_ARM64_REG_PC,UC_ARM64_REG_SP
def parse(b):
 p=32;segs=[];syms=None;ind=None;stubsec=None;selectors=[]
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  c,s=struct.unpack_from('<II',b,p)
  if c==2:syms=struct.unpack_from('<4I',b,p+8)
  if c==0xb:ind=struct.unpack_from('<II',b,p+56)
  if c==0x19:
   vm,vs,fo,fs=struct.unpack_from('<4Q',b,p+24);segs.append((vm,vs,fo,fs))
   for i in range(struct.unpack_from('<I',b,p+64)[0]):
    q=p+72+80*i
    if b[q:q+16].split(b'\0')[0]==b'__objc_selrefs':
     va,size,fo=struct.unpack_from('<QQI',b,q+32)
     for j in range(0,size,8):selectors.append((va+j,struct.unpack_from('<Q',b,fo+j)[0]&0xfffffffff))
    if b[q:q+16].split(b'\0')[0]==b'__stubs':
     va,size=struct.unpack_from('<QQ',b,q+32);first,entrysize=struct.unpack_from('<II',b,q+68);stubsec=(va,size,first,entrysize)
  p+=s
 so,n,st,ss=syms;symbols=[];addresses={}
 for i in range(n):
  no,t,se,d,v=struct.unpack_from('<IBBHQ',b,so+16*i);name=b[st+no:st+ss].split(b'\0')[0].decode();symbols.append(name)
  if not t&0xe0 and t&0xe==0xe:addresses[name]=v
 va,size,first,entrysize=stubsec;io,ic=ind;stubs={}
 for i in range(size//entrysize):
  si=struct.unpack_from('<I',b,io+4*(first+i))[0];stubs[va+entrysize*i]=symbols[si]
 return segs,addresses,stubs,selectors

if len(sys.argv)!=2:raise SystemExit('Usage: test-registration-arm64.py VVProfile15_BINARY')
b=Path(sys.argv[1]).read_bytes();segs,symbols,stubs,selectors=parse(b)
uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
for start,size in [(0,0x40000),(0x100000,0x20000),(0x200000,0x10000),(0x300000,0x1000)]:uc.mem_map(start,size)
for vm,vs,off,fs in segs:
 if fs:uc.mem_write(vm,b[off:off+fs])
for address,target in selectors:uc.mem_write(address,struct.pack('<Q',target))
BUILDER=0x109000;BUILDER_ENTRY=0x111000;BLOCK=0x10a000;OUTPUT=0x10b000;SEL=0x10c000;STOP=0x300000;TYPE=0x10d000
uc.mem_write(BUILDER,struct.pack('<QQQQ',0x10e000,0,BUILDER_ENTRY,0));uc.mem_write(BLOCK,struct.pack('<Q',0x10e000));uc.mem_write(TYPE,b'@@:@\0')
parents={};own={};tokens={};token_owner={};built=[];wrapped={};last_capture=None

def resolve(cls,selector):
 c=cls
 while c:
  if (c,selector) in own:return (c,selector)
  c=parents.get(c,0)
 return None

def ret(value):
 uc.reg_write(UC_ARM64_REG_X0,value);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))

def callback(uc,address,size,unused):
 global last_capture
 if address==BUILDER_ENTRY:
  assert uc.reg_read(UC_ARM64_REG_X0)==BUILDER
  last_capture=uc.reg_read(UC_ARM64_REG_X1);built.append(last_capture);ret(BLOCK);return
 name=stubs.get(address)
 if not name:return
 x0=uc.reg_read(UC_ARM64_REG_X0);x1=uc.reg_read(UC_ARM64_REG_X1);x2=uc.reg_read(UC_ARM64_REG_X2)
 if name=='_class_getInstanceMethod':
  owner=resolve(x0,x1)
  if owner is None:ret(0);return
  if owner not in tokens:
   token=0x103000+len(tokens)*16;tokens[owner]=token;token_owner[token]=owner
  ret(tokens[owner])
 elif name=='_method_getImplementation':ret(own[token_owner[x0]])
 elif name=='_method_getTypeEncoding':ret(TYPE)
 elif name=='_imp_implementationWithBlock':
  assert x0==BLOCK and struct.unpack('<Q',uc.mem_read(BLOCK,8))[0]==0x10e000
  replacement=0x190000+len(wrapped)*16;wrapped[replacement]=last_capture;ret(replacement)
 elif name=='_class_addMethod':
  if (x0,x1) in own:ret(0)
  else:own[x0,x1]=x2;ret(1)
 elif name=='_class_replaceMethod':
  prior=own[x0,x1];own[x0,x1]=x2;ret(prior)
 elif name in ['_objc_retainAutoreleasedReturnValue','_objc_retain','_objc_retainBlock','_objc_autoreleaseReturnValue']:ret(x0)
 elif name=='_objc_release':ret(0)
 else:raise AssertionError(('unexpected runtime call',name))

uc.hook_add(UC_HOOK_CODE,callback)
def install(cls):
 uc.mem_write(OUTPUT,struct.pack('<Q',0xfeedface))
 uc.reg_write(UC_ARM64_REG_SP,0x20fff0);uc.reg_write(UC_ARM64_REG_LR,STOP)
 for reg,v in [(UC_ARM64_REG_X0,cls),(UC_ARM64_REG_X1,SEL),(UC_ARM64_REG_X2,BUILDER),(UC_ARM64_REG_X3,OUTPUT)]:uc.reg_write(reg,v)
 uc.emu_start(symbols['_Install'],STOP,count=100000)
 assert uc.reg_read(UC_ARM64_REG_PC)==STOP
 return uc.reg_read(UC_ARM64_REG_X0)&0xff,struct.unpack('<Q',uc.mem_read(OUTPUT,8))[0]
BASE=0x101000;CHILD=0x101100;OTHER=0x101200
own[BASE,SEL]=0x180000;parents[CHILD]=BASE;own[OTHER,SEL]=0x181000
ok,previous=install(BASE);assert ok and previous==0x180000
base_wrapper=own[BASE,SEL];assert wrapped[base_wrapper]==0x180000
count=len(built);ok,previous=install(BASE);assert ok and previous==0x180000 and len(built)==count
ok,previous=install(CHILD);assert ok and previous==base_wrapper
child_wrapper=own[CHILD,SEL];assert child_wrapper!=base_wrapper and wrapped[child_wrapper]==base_wrapper
count=len(built);ok,previous=install(CHILD);assert ok and previous==base_wrapper and len(built)==count
ok,previous=install(OTHER);assert ok and previous==0x181000 and wrapped[own[OTHER,SEL]]==0x181000
ok,previous=install(0x101300);assert not ok and previous==0xfeedface
for i in range(61):
 cls=0x110000+i*16;own[cls,SEL]=0x182000+i*16
 ok,previous=install(cls);assert ok and previous==0x182000+i*16
cls=0x110ff0;own[cls,SEL]=0x18f000;count=len(built)
ok,previous=install(cls);assert not ok and previous==0xfeedface and len(built)==count and own[cls,SEL]==0x18f000
assert len(wrapped)==64
print('PASS: actual ARM64 Install captures the prior IMP, avoids repeated installation, preserves inherited wrapper chains, isolates another class, leaves missing methods untouched, and fails safely at capacity.')
print('LIMIT: runtime calls and builder block are mocked; this does not test block-trampoline execution, Foundation, iOS signing, networking, or app launch.')
