from pathlib import Path
import struct,hashlib,plistlib,zipfile,sys
from macho_helpers import commands,add_command,blobs,sign
if len(sys.argv)!=3:raise SystemExit('Usage: package-framework.py ORIGINAL_IPA OUTPUT_DIRECTORY')
SOURCE=Path(sys.argv[1]);OUT=Path(sys.argv[2]);OUT.mkdir(parents=True,exist_ok=True)
APP='Payload/VVebo.app/'
FRAMEWORK='Frameworks/VVProfile15.framework/'
root=Path(__file__).resolve().parent
framework_binary=(root/'VVProfile15').read_bytes()
cd=blobs(framework_binary)[0]
cdhash=hashlib.sha256(cd).digest()[:20]
framework_info=plistlib.dumps({
 'CFBundleExecutable':'VVProfile15','CFBundleIdentifier':'com.johnil.vvebo.profile15',
 'CFBundleInfoDictionaryVersion':'6.0','CFBundleName':'VVProfile15','CFBundlePackageType':'FMWK',
 'CFBundleShortVersionString':'1.0','CFBundleVersion':'1','MinimumOSVersion':'14.0',
 'CFBundleSupportedPlatforms':['iPhoneOS'],'DTPlatformName':'iphoneos','DTSDKName':'iphoneos15.5'
},fmt=plistlib.FMT_XML,sort_keys=True)
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='6e497fb4c6e264e66b05a3289f1eed9958a0cea7792fbaf00e1484fcd31e4ed5', 'Use the verified original IPA'
with zipfile.ZipFile(SOURCE) as z:
 original={i.filename:z.read(i.filename) for i in z.infolist()};metas={i.filename:i for i in z.infolist()}
files=original.copy();info=plistlib.loads(files[APP+'Info.plist'])
info['VVProfile15Build']='a'
info['CFBundleVersion']='4.1501';info['CFBundleDisplayName']='VVebo 15A'
files[APP+'Info.plist']=plistlib.dumps(info,fmt=plistlib.FMT_BINARY,sort_keys=False)
files[APP+FRAMEWORK+'VVProfile15']=framework_binary
files[APP+FRAMEWORK+'Info.plist']=framework_info
resourcepath=APP+'_CodeSignature/CodeResources';resources=plistlib.loads(files[resourcepath])
legacy=resources.setdefault('files',{})
if 'Info.plist' in legacy:
 old=legacy['Info.plist'];digest=hashlib.sha1(files[APP+'Info.plist']).digest()
 if isinstance(old,dict):old=dict(old);old['hash']=digest;legacy['Info.plist']=old
 else:legacy['Info.plist']=digest
for rel in [FRAMEWORK+'Info.plist',FRAMEWORK+'VVProfile15']:
 legacy[rel]=hashlib.sha1(files[APP+rel]).digest()
resources.setdefault('files2',{})['Frameworks/VVProfile15.framework']={'cdhash':cdhash,'requirement':'cdhash H"'+cdhash.hex()+'"'}
files[resourcepath]=plistlib.dumps(resources,fmt=plistlib.FMT_XML,sort_keys=True)
main=bytearray(files[APP+'VVebo'])
path=b'@executable_path/Frameworks/VVProfile15.framework/VVProfile15\0'
size=(24+len(path)+7)&~7;cmd=struct.pack('<6I',0xc,size,24,2,0x10000,0x10000)+path;cmd+=b'\0'*(size-len(cmd));add_command(main,cmd)
files[APP+'VVebo'],mainhash=sign(main,info['CFBundleIdentifier'],files[APP+'Info.plist'],files[resourcepath])
target=OUT/'VVebo-3.3.31-iOS15-Profile-A.ipa'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in files.items():
  if name in metas:
   meta=zipfile.ZipInfo(name,metas[name].date_time);meta.external_attr=metas[name].external_attr;meta.create_system=metas[name].create_system
  else:
   meta=zipfile.ZipInfo(name);meta.create_system=3;meta.external_attr=((0o100755 if name.endswith('/VVProfile15') else 0o100644)<<16)
  meta.compress_type=zipfile.ZIP_DEFLATED;z.writestr(meta,data)
print(target.name,'bytes',target.stat().st_size,'SHA256',hashlib.sha256(target.read_bytes()).hexdigest())
