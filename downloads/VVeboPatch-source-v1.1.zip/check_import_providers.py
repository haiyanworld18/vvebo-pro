import struct,zipfile,collections,pathlib

def imports(b):
 if b[:4]!=b'\xcf\xfa\xed\xfe':return {}
 libs=[];p=32;symbols=None
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  c,s=struct.unpack_from('<II',b,p)
  if c in [0xc,0x80000018,0x8000001f,0x80000023]:
   n=struct.unpack_from('<I',b,p+8)[0];libs.append(b[p+n:p+s].split(b'\0')[0].decode())
  if c==2:symbols=struct.unpack_from('<4I',b,p+8)
  p+=s
 if not symbols:return {}
 so,n,st,sz=symbols;out={}
 for i in range(n):
  name,typ,sect,desc,val=struct.unpack_from('<IBBHQ',b,so+16*i)
  if typ&0xe0 or typ&0xe or not name:continue
  ord=desc>>8
  if 0<ord<=len(libs):out[b[st+name:st+sz].split(b'\0')[0].decode()]=libs[ord-1]
 return out
patch=imports(pathlib.Path('/workspace/vvebo-analysis/patch/VVeboPatch.dylib').read_bytes())
observed=collections.defaultdict(set)
p='/workspace/attachments/13f0b5c6-0601-438c-bcc6-123d94ddb42a/VVebo砸壳_3.3.31_纯净无弹窗.ipa'
with zipfile.ZipFile(p) as z:
 for n in z.namelist():
  if n.endswith('/') or not (n=='Payload/VVebo.app/VVebo' or '/Frameworks/' in n):continue
  b=z.read(n)
  for name,provider in imports(b).items():
   if name in patch:observed[name].add(provider)
for name,provider in patch.items():
 if observed[name] and provider not in observed[name]:
  print('MISMATCH:',name,'patch:',provider,'original imports:',sorted(observed[name]))
