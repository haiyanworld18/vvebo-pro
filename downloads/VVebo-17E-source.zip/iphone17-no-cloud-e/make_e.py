from pathlib import Path
import sys,struct,hashlib,json,zipfile,plistlib
from macho_helpers import sign
from macho_plan import make_plan,metadata
ROOT=Path(__file__).resolve().parent
APP='Payload/VVebo.app/'
RET=bytes.fromhex('c0035fd6');NIL=bytes.fromhex('000080d2')
A_HASH='46c2c14389780a5a7743b435439b58e5ebe3d3c4e1bf6552b490b49ee84224b6'
CONTAINERS=[0x3096b4,0x309c04,0x309d0c,0x30a4c0,0x30ba70,0x30bd20]
MASTERS={0x30a388:'CloudCenter native checkStatus; Boolean input, no completion argument',0x30c3f4:'Objective-C checkStatus: wrapper',0x2a5c30:'AppDelegate native scheduled syncCloud; no arguments/completion',0x29fb60:'Objective-C syncCloud wrapper',0x3114c8:'Main-view cloud feed restore; no input completion argument'}
def branch(off,target,link=False):
 delta=target-off;assert delta%4==0 and -(1<<27)<=delta<(1<<27)
 return struct.pack('<I',(0x94000000 if link else 0x14000000)|((delta//4)&0x3ffffff))
def patch_plan(b):
 plan=make_plan(b);sections,stubs,classes,selectors,functions=metadata(b)
 creators={a['function'] for a in plan['allocations']+plan['constructors']}
 assert len(creators)==23 and 0x31575c in creators
 retain=next(v-0x100000000 for v,n in stubs.items() if n=='_swift_bridgeObjectRetain')
 patches=[]
 def add(off,val,purpose):patches.append({'file_offset':off,'before':b[off:off+4].hex(),'after':val.hex(),'purpose':purpose})
 for off in CONTAINERS:
  assert b[off:off+4]==branch(off,0x565578,True)
  add(off,NIL,'Leave unavailable cloud container nil; preserve constructor and local object fields')
 for off in sorted(creators):
  assert off+0x100000000 in functions
  if off==0x31575c:
   # This helper returns its input Swift array with +1 ownership. Returning a
   # retained original array skips cloud conversion/writes without returning nil,
   # fabricating saved records, or losing the caller's owned result convention.
   add(off,branch(off,retain),'Cancel cloud config conversion/write; return retained unchanged input array')
  else:add(off,RET,'Disabled native query/save helper; borrowed inputs and ignored Void result')
 for off,purpose in sorted(MASTERS.items()):
  assert off+0x100000000 in functions
  add(off,RET,'Disabled feature entry: '+purpose)
 assert len(patches)==34 and len({p['file_offset'] for p in patches})==34
 return patches,plan,retain

def main():
 base,out=map(Path,sys.argv[1:]);out.mkdir(parents=True,exist_ok=True)
 assert hashlib.sha256(base.read_bytes()).hexdigest()==A_HASH
 with zipfile.ZipFile(base) as z:files={i.filename:z.read(i.filename) for i in z.infolist()};metas={i.filename:i for i in z.infolist()}
 b=files[APP+'VVebo'];patches,plan,retain=patch_plan(b);main=bytearray(b)
 for p in patches:off=p['file_offset'];main[off:off+4]=bytes.fromhex(p['after'])
 info=plistlib.loads(files[APP+'Info.plist']);info['CFBundleDisplayName']='VVebo 17E';info['CFBundleVersion']='4.1705';info['VVProfile17Compatibility']='cloud-feature-entries-disabled-e'
 files[APP+'Info.plist']=plistlib.dumps(info,fmt=plistlib.FMT_BINARY,sort_keys=False)
 rp=APP+'_CodeSignature/CodeResources';res=plistlib.loads(files[rp]);old=res['files']['Info.plist'];h=hashlib.sha1(files[APP+'Info.plist']).digest()
 if isinstance(old,dict):old=dict(old);old['hash']=h
 else:old=h
 res['files']['Info.plist']=old;files[rp]=plistlib.dumps(res,fmt=plistlib.FMT_XML,sort_keys=True)
 files[APP+'VVebo'],_=sign(main,info['CFBundleIdentifier'],files[APP+'Info.plist'],files[rp])
 path=out/'VVebo-3.3.31-iPhone17-NoCloud-E.ipa'
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,data in files.items():
   old=metas[name];zi=zipfile.ZipInfo(name,old.date_time);zi.external_attr=old.external_attr;zi.create_system=old.create_system;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,data)
 manifest={'baseline':'Verified 15A; no B/C/D binary used','patches':patches,'operation_creator_functions_disabled':23,'master_entries_disabled':5,'borrowed_array_return_helper':hex(0x31575c),'bridge_retain_stub':hex(retain),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 (out/'iPhone17-E-patch-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(path.name,path.stat().st_size,manifest['sha256'])
if __name__=='__main__':main()
