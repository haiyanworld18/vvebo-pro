"""Execute one iteration of original main-view cloud-account loop after disabling."""
import struct,zipfile,sys
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
BASE=0x100000000;ARRAY=0x300001000;STRING=0x300002000;CLOUD=0x300003000
with zipfile.ZipFile(sys.argv[1]) as z:b=z.read('Payload/VVebo.app/VVebo')
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x800000);u.mem_write(BASE,b);u.mem_map(0x300000000,0x10000);u.mem_map(0x400000000,0x10000)
u.mem_write(ARRAY,struct.pack('<QQ',0x72657375,STRING));u.mem_write(CLOUD,bytes(range(64)));original=bytes(u.mem_read(CLOUD,64));events=[]
for r,v in [(UC_ARM64_REG_SP,0x40000fff0),(UC_ARM64_REG_X20,CLOUD),(UC_ARM64_REG_X24,1),(UC_ARM64_REG_X25,ARRAY+8)]:u.reg_write(r,v)
def hook(u,pc,sz,data):
 if pc in [BASE+0x5659c8,BASE+0x5659b0]:
  assert u.reg_read(UC_ARM64_REG_X0)==STRING;events.append(pc-BASE);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
u.hook_add(UC_HOOK_CODE,hook);u.emu_start(BASE+0x27d7ec,BASE+0x27d81c,count=200)
assert u.reg_read(UC_ARM64_REG_PC)==BASE+0x27d81c and u.reg_read(UC_ARM64_REG_X24)==0
assert events==[0x5659c8,0x5659b0] and bytes(u.mem_read(CLOUD,64))==original
print('PASS: original main-view per-account loop returns through E disabled query, balances string retain/release, advances to the next UI initialization instruction and leaves modeled cloud/account bytes unchanged.')
print('LIMIT: runtime reference calls are mocked; remaining viewDidLoad and UIKit execution are not tested.')
