import struct,bisect
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN
from capstone.arm64_const import ARM64_OP_REG,ARM64_OP_IMM,ARM64_OP_MEM
BASE=0x100000000

def cstr(b,off):return b[off:b.find(b'\0',off)].decode()
def metadata(b):
 p=32;sections={};funcs=[]
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  cmd,size=struct.unpack_from('<II',b,p)
  if cmd==2:so,n,st,ss=struct.unpack_from('<4I',b,p+8)
  if cmd==0xb:io,ni=struct.unpack_from('<II',b,p+56)
  if cmd==0x26:fs,fn=struct.unpack_from('<II',b,p+8)
  if cmd==0x80000034:
   d,_=struct.unpack_from('<II',b,p+8);head=struct.unpack_from('<7I',b,d);imports=d+head[2];strings=d+head[3];assert head[5]==1
  if cmd==0x19:
   for i in range(struct.unpack_from('<I',b,p+64)[0]):
    q=p+72+80*i;name=b[q:q+16].split(b'\0')[0].decode();va,sz,fo=struct.unpack_from('<QQI',b,q+32);r1,r2=struct.unpack_from('<II',b,q+68);sections[name]=(va,sz,fo,r1,r2)
  p+=size
 syms=[]
 for i in range(n):
  no=struct.unpack_from('<I',b,so+16*i)[0];syms.append(cstr(b,st+no))
 va,sz,fo,first,stride=sections['__stubs'];stubs={}
 for i in range(sz//stride):
  index=struct.unpack_from('<I',b,io+4*(first+i))[0];stubs[va+i*stride]=syms[index]
 classes={};va,sz,fo,_,_=sections['__objc_classrefs']
 for i in range(0,sz,8):
  val=struct.unpack_from('<Q',b,fo+i)[0]
  if val>>63:
   word=struct.unpack_from('<I',b,imports+4*(val&0xffffff))[0];classes[va+i]=cstr(b,strings+(word>>9))
 selectors={};va,sz,fo,_,_=sections['__objc_selrefs']
 for i in range(0,sz,8):
  ptr=struct.unpack_from('<Q',b,fo+i)[0]&0xfffffffff
  if BASE<=ptr<BASE+len(b):selectors[va+i]=cstr(b,ptr-BASE)
 p=fs;a=BASE
 while p<fs+fn:
  val=0;shift=0
  while True:
   x=b[p];p+=1;val|=(x&127)<<shift;shift+=7
   if not x&128:break
  if not val:break
  a+=val;funcs.append(a)
 return sections,stubs,classes,selectors,funcs

def make_plan(b):
 sections,stubs,classes,selectors,funcs=metadata(b)
 md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN);md.detail=True
 def rn(reg):
  name=md.reg_name(reg)
  return 'x'+name[1:] if name.startswith('w') else name
 def function(pc):return funcs[bisect.bisect_right(funcs,pc)-1]
 def state_before(pc):
  start=max(function(pc),pc-40);state={}
  for ins in md.disasm(b[start-BASE:pc-BASE],start):
   ops=ins.operands;newreg=None;newval=None
   if ins.mnemonic=='adrp':newreg=rn(ops[0].reg);newval=('addr',ops[1].imm)
   elif ins.mnemonic=='adr':newreg=rn(ops[0].reg);newval=('addr',ops[1].imm)
   elif ins.mnemonic=='mov' and len(ops)>1 and ops[0].type==ARM64_OP_REG and ops[1].type==ARM64_OP_REG:newreg=rn(ops[0].reg);newval=state.get(rn(ops[1].reg))
   elif ins.mnemonic=='add' and len(ops)==3 and ops[2].type==ARM64_OP_IMM:
    origin=state.get(rn(ops[1].reg));newreg=rn(ops[0].reg)
    if origin and origin[0]=='addr':newval=('addr',origin[1]+ops[2].imm)
   elif ins.mnemonic=='ldr' and len(ops)==2:
    address=None
    if ops[1].type==ARM64_OP_MEM:
     origin=state.get(rn(ops[1].mem.base))
     if origin and origin[0]=='addr':address=origin[1]+ops[1].mem.disp
    elif ops[1].type==ARM64_OP_IMM:address=ops[1].imm
    newreg=rn(ops[0].reg)
    if address in classes:newval=('class',classes[address])
    elif address in selectors:newval=('selector',selectors[address])
   if ins.mnemonic=='bl':
    old=state.get('x0');name=stubs.get(ops[0].imm)
    for i in range(19):state.pop('x'+str(i),None)
    if name in ['_objc_opt_self','_objc_retain','_objc_retainAutoreleasedReturnValue'] and old:state['x0']=old
   elif ins.mnemonic.startswith('b') or ins.mnemonic in ['ret','blr','br']:state.clear()
   else:
    _,written=ins.regs_access()
    for reg in written:state.pop(rn(reg),None)
    if newreg and newval:state[newreg]=newval
  return state
 allocations=[];completions=[]
 va,sz,fo,_,_=sections['__text']
 for off in range(fo,fo+sz,4):
  w=struct.unpack_from('<I',b,off)[0]
  if w&0xfc000000!=0x94000000:continue
  imm=w&0x3ffffff
  if imm&(1<<25):imm-=1<<26
  pc=BASE+off;target=pc+(imm<<2);name=stubs.get(target)
  if not name or not (name.startswith('_objc_alloc') or name in ['_objc_opt_new','_objc_msgSend']):continue
  state=state_before(pc)
  klass=state.get('x0');sel=state.get('x1')
  if klass in [('class','_OBJC_CLASS_$_CKQueryOperation'),('class','_OBJC_CLASS_$_CKModifyRecordsOperation')] and (name.startswith('_objc_alloc') or name=='_objc_opt_new' or (name=='_objc_msgSend' and sel in [('selector','alloc'),('selector','new')])):
   allocations.append({'file_offset':off,'function':function(pc)-BASE,'class':klass[1],'allocator':name})
  if name=='_objc_msgSend' and sel in [('selector','setQueryCompletionBlock:'),('selector','setModifyRecordsCompletionBlock:')]:
   completions.append({'file_offset':off,'function':function(pc)-BASE,'kind':'pair' if sel[1]=='setQueryCompletionBlock:' else 'triple','selector':sel[1]})
 constructor_stub=next(va for va,name in stubs.items() if name=='_$sSo24CKModifyRecordsOperationC8CloudKitE13recordsToSave09recordIDsG6DeleteABSaySo8CKRecordCGSg_SaySo0L2IDCGSgtcfC')
 constructors=[]
 for off in range(fo,fo+sz,4):
  word=struct.unpack_from('<I',b,off)[0]
  if word&0xfc000000!=0x94000000:continue
  delta=word&0x3ffffff
  if delta&(1<<25):delta-=1<<26
  if BASE+off+(delta<<2)==constructor_stub:constructors.append({'file_offset':off,'function':function(BASE+off)-BASE})
 assert [a['file_offset'] for a in constructors]==[0x3060c8,0x316564,0x32cac0], constructors
 assert len(allocations)==20 and len(completions)==22
 assert sorted(a['function'] for a in allocations+constructors if a['function']!=0x305ff0)==sorted(a['function'] for a in completions)
 bridge_release=next(va-BASE for va,name in stubs.items() if name=='_swift_bridgeObjectRelease')
 dlsym=next(va-BASE for va,name in stubs.items() if name=='_dlsym')
 return {'constructors':constructors,'bridge_release_stub_offset':bridge_release,'allocations':allocations,'completions':completions,'dlsym_stub_offset':dlsym,'main_text_offset':sections['__text'][2],'load_commands_end':32+struct.unpack_from('<I',b,20)[0]}

if __name__=='__main__':
 import zipfile,json,sys
 with zipfile.ZipFile(sys.argv[1]) as z:b=z.read('Payload/VVebo.app/VVebo')
 plan=make_plan(b)
 print('Allocations:',len(plan['allocations']),'completion setters:',len(plan['completions']))
 for a in plan['allocations']:print('ALLOC',hex(a['file_offset']),a['class'],hex(a['function']))
 for a in plan['completions']:print('COMPLETION',hex(a['file_offset']),a['kind'],hex(a['function']))
 if len(sys.argv)>2:open(sys.argv[2],'w').write(json.dumps(plan,indent=2)+'\n')
