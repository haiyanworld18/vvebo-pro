# VVebo 17E: disable cloud feature boundaries

User explicitly requested cancelling cloud sync after D white-screened. E starts from the unchanged, user-verified iOS 15 15A IPA. Target: iPhone 17 Pro Max / iOS 26 / re-signing in 全能签. Device launch/login remains unverified.

E does not include D's relinked framework, injected header gates, dlsym helpers, NSError creation or queued cloud completions. It keeps the exact A homepage networking framework, original text geometry, original caller cleanup paths, all UI resources and original entitlements. Root display name VVebo 17E, build 4.1705.

34 instruction replacements, individually listed in the manifest:

- Six default-container sends return nil, preserving the original CloudCenter initialization and local fields. These are the B changes that allowed pre-login launch.
- Twenty-two identified query/save helper functions return immediately before allocating/capturing any cloud operation. They use borrowed parameters and have no used return value at their inspected callers. Callers keep their original cleanup. No completion or invented cloud success/failure is emitted.
- The 23rd operation-creating function, 0x31575c, also returns a Swift array that callers release or inspect. It is NOT replaced by a Void return. Original return 0x31661c loads the current input array from fp-0x60; callers at 0x30a744 release the owned result and at 0x31720c inspect it. E tail-calls the existing swift_bridgeObjectRetain stub with the input x0, returning the same original array with +1 ownership. It skips cloud conversion/writes and does not create saved-record or purchase-success objects.
- Five feature boundaries return immediately: native and Objective-C CloudCenter.checkStatus, native and Objective-C AppDelegate.syncCloud, and the launch-time cloud-feed restore routine. The state-check takes a Boolean and the sync/restore entries have no completion argument. These skip cloud workflows instead of starting a transaction and waiting for it.

The original cloud menu/interface strings are retained; cloud-related controls may still be visible and unavailable. Manual cloud restoration, cloud-backed customization and cloud account/purchase refresh are disabled. Local and Weibo-server features need device verification. No new account/data deletion is added and purchase status is not forced. The original app still contains and links CloudKit and other record/notification routines; this is not a claim that every CloudKit instruction has been removed.

Python 3 plus capstone is needed to build/verify. No new Objective-C code is compiled. Obtain the public verified A IPA with SHA256 46c2c14389780a5a7743b435439b58e5ebe3d3c4e1bf6552b490b49ee84224b6:

    python make_e.py /path/to/A.ipa /path/to/output
    python verify_e.py /path/to/A.ipa /path/to/output/VVebo-3.3.31-iPhone17-NoCloud-E.ipa

With unicorn installed:

    python test_entries_arm64.py /path/to/E.ipa /path/to/iPhone17-E-patch-manifest.json
    python test_callers_arm64.py /path/to/A.ipa /path/to/E.ipa
    python test_mainview_arm64.py /path/to/E.ipa
    python test_cloud_arm64.py /path/to/A.ipa /path/to/E.ipa

Checks validate exactly three changed files; 34 native instruction replacements; restored A header/text extent, caller instructions and framework bytes; preserved entitlements and code/resource hashes. ARM64 tests execute actual packaged entry instructions, both login/account-view caller slices and the main-view account-query loop iteration. They check stack/register preservation, original caller cleanup and the config return's owned array. Runtime/Swift/CloudKit behaviors are mocked. The main-view test reaches the following UI-init instruction but does not execute the rest of viewDidLoad or UIKit. Full startup, login, persistent storage, UI, signing trust, live APIs and display adaptation are NOT proven by these tests. There is no display adaptation in E.

Do not publish raw user crash reports, signed IPAs, profiles, certificates or device identifiers.
