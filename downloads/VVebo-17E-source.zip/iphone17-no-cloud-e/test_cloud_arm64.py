"""Run exact app instruction slices under ARM64 emulation.
CloudKit authorization and Objective-C runtime behavior are mocked; this is not
an iOS/CloudKit simulator and does not test complete application startup.
"""
from pathlib import Path
import zipfile,struct,sys
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X21,UC_ARM64_REG_X23,UC_ARM64_REG_PC
BASE=0x100000000
OFFSETS=[0x3096b4,0x309c04,0x309d0c,0x30a4c0,0x30ba70,0x30bd20]
SELF=0x300000100;CLASS=0x300009000;CONTAINER=0x300003000;DB=0x300004000
from unicorn.arm64_const import UC_ARM64_REG_LR
class MissingCloudAuthorization(Exception):pass

def image(path):
 with zipfile.ZipFile(path) as z:return z.read('Payload/VVebo.app/VVebo')

def execute(binary,start,end,authorized,full=False):
 uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 uc.mem_map(BASE,0x900000);uc.mem_map(0x300000000,0x10000)
 p=32
 for _ in range(struct.unpack_from('<I',binary,16)[0]):
  c,s=struct.unpack_from('<II',binary,p)
  if c==0x19:
   va,vs,fo,fs=struct.unpack_from('<4Q',binary,p+24)
   if fs:uc.mem_write(va,binary[fo:fo+fs])
  p+=s
 for off in [0x6cc108,0x6cc138]:
  target=struct.unpack_from('<Q',binary,off)[0]&0xfffffffff
  uc.mem_write(BASE+off,struct.pack('<Q',target))
 selector=struct.unpack_from('<Q',uc.mem_read(BASE+0x6cc108,8))[0]
 uc.reg_write(UC_ARM64_REG_X0,CLASS);uc.reg_write(UC_ARM64_REG_X1,selector)
 uc.reg_write(UC_ARM64_REG_X21,SELF);uc.reg_write(UC_ARM64_REG_X23,24)
 uc.mem_write(SELF,struct.pack('<Q',CLASS));uc.mem_write(SELF+24,struct.pack('<Q',0xaaaaaaaaaaaaaaaa))
 stats={'default_calls':0,'nil_receiver_calls':0,'completed':False}
 def text(p):
  v=[]
  for _ in range(100):
   b=bytes(uc.mem_read(p,1));p+=1
   if b==b'\0':return b''.join(v).decode()
   v.append(b)
  raise AssertionError('bad selector')
 def ret(v):uc.reg_write(UC_ARM64_REG_X0,v);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))
 def run(uc,pc,size,data):
  if pc==BASE+0x5655c0:ret(CLASS)
  elif pc==BASE+0x5655fc:ret(uc.reg_read(UC_ARM64_REG_X0))
  elif pc==BASE+0x5655cc:ret(uc.reg_read(UC_ARM64_REG_X0))
  elif pc==BASE+0x565578:
   receiver=uc.reg_read(UC_ARM64_REG_X0);sel=text(uc.reg_read(UC_ARM64_REG_X1))
   if not receiver:stats['nil_receiver_calls']+=1;ret(0);return
   if sel=='defaultContainer':
    stats['default_calls']+=1
    if not authorized:raise MissingCloudAuthorization()
    ret(CONTAINER)
   elif sel=='publicCloudDatabase':assert receiver==CONTAINER;ret(DB)
   else:raise AssertionError(sel)
 uc.hook_add(UC_HOOK_CODE,run)
 try:
  uc.emu_start(BASE+start,BASE+end,count=1000)
  assert uc.reg_read(UC_ARM64_REG_PC)==BASE+end
  stats['completed']=True
 except MissingCloudAuthorization:pass
 stats['result']=uc.reg_read(UC_ARM64_REG_X0)
 stats['db_slot']=struct.unpack('<Q',uc.mem_read(SELF+24,8))[0]
 assert struct.unpack('<Q',uc.mem_read(SELF,8))[0]==CLASS
 return stats

if len(sys.argv)!=3:raise SystemExit('Usage: test_cloud_arm64.py BASELINE_A_IPA COMPAT_B_IPA')
a=image(sys.argv[1]);b=image(sys.argv[2])
for off in OFFSETS:
 before=execute(a,off,off+12,False);assert not before['completed'] and before['default_calls']==1
 after=execute(b,off,off+12,False);assert after['completed'] and after['default_calls']==0 and after['result']==0
positive=execute(a,0x30969c,0x3096f0,True,True);assert positive['completed'] and positive['db_slot']==DB
negative=execute(a,0x30969c,0x3096f0,False,True);assert not negative['completed']
compat=execute(b,0x30969c,0x3096f0,False,True)
assert compat['completed'] and compat['default_calls']==0 and compat['nil_receiver_calls']==1 and compat['db_slot']==0
print('PASS: all 6 exact machine-code slices skip defaultContainer and produce nil; the initializer slice continues through nil messaging and stores a nil DB without altering the object header.')
print('CONTROL: original slice stores a real DB with mocked authorization, and stops at the mocked CloudKit exception without it.')
print('LIMIT: CloudKit and runtime calls are mocked. Complete initialization, later nil-DB uses, signing and on-device startup remain unverified.')
