import struct,hashlib
def cmds(b):
 p=32
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  c,s=struct.unpack_from('<II',b,p);assert s>=8 and s%8==0;yield p,c,s;p+=s
 assert p==32+struct.unpack_from('<I',b,20)[0]
def signature(b,info=None,resources=None):
 p=next(p for p,c,s in cmds(b) if c==0x1d)
 off,size=struct.unpack_from('<II',b,p+8);assert off+size==len(b)
 magic,length,n=struct.unpack_from('>III',b,off);assert magic==0xfade0cc0 and length==size
 blobs={}
 for i in range(n):
  k,r=struct.unpack_from('>II',b,off+12+8*i);ln=struct.unpack_from('>I',b,off+r+4)[0];blobs[k]=b[off+r:off+r+ln]
 cd=blobs[0]
 magic,ln,version,flags,ho,ident,ns,nc,limit=struct.unpack_from('>9I',cd)
 assert magic==0xfade0c02 and flags&2 and len(cd)==ln and limit==off
 assert cd[36:40]==bytes([32,2,0,12]);assert nc==(limit+4095)//4096
 for i in range(nc):assert cd[ho+32*i:ho+32*(i+1)]==hashlib.sha256(b[i*4096:min(limit,4096*(i+1))]).digest(),('page',i)
 special={}
 if info is not None:special[1]=info
 if resources is not None:special[3]=resources
 special.update({k:v for k,v in blobs.items() if k in [5,7]})
 for k,v in special.items():assert cd[ho-32*k:ho-32*(k-1)]==hashlib.sha256(v).digest(),('special slot',k)
 return blobs,hashlib.sha256(cd).digest()[:20]
def section_bytes(b,name):
 for p,c,s in cmds(b):
  if c!=0x19:continue
  count=struct.unpack_from('<I',b,p+64)[0]
  for i in range(count):
   q=p+72+i*80
   if b[q:q+16].split(b'\0')[0]==name:
    size,offset=struct.unpack_from('<QI',b,q+40);return b[offset:offset+size]
 raise AssertionError(name)