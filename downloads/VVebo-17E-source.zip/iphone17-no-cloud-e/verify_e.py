from pathlib import Path
import zipfile,plistlib,struct,hashlib,sys
from make_e import APP,A_HASH,patch_plan
from macho_helpers import blobs
from validation_helpers import cmds,signature,section_bytes
base,target=map(Path,sys.argv[1:]);assert hashlib.sha256(base.read_bytes()).hexdigest()==A_HASH
with zipfile.ZipFile(base) as z:old={n:z.read(n) for n in z.namelist()}
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None;files={n:z.read(n) for n in z.namelist()}
assert set(old)==set(files)
assert {n for n in files if old[n]!=files[n]}=={APP+'VVebo',APP+'Info.plist',APP+'_CodeSignature/CodeResources'}
b=old[APP+'VVebo'];main=files[APP+'VVebo'];patches,plan,retain=patch_plan(b)
expected=bytearray(section_bytes(b,b'__text'))
for p in patches:
 off=p['file_offset'];expected[off-0x66d8:off-0x66d8+4]=bytes.fromhex(p['after'])
assert section_bytes(main,b'__text')==expected
assert main[0x3400:0x66d8]==b[0x3400:0x66d8],'D header gates must not be present'
for off in [0x241944,0xc9220,0x27d804]:assert main[off:off+4]==b[off:off+4],'Callers should retain original cleanup paths'
# No load commands/section geometry changes, apart from signature and linkedit size.
for (p,c,s),(op,oc,os) in zip(cmds(main),cmds(b)):
 assert (p,c,s)==(op,oc,os)
 if c==0x1d:continue
 if c==0x19 and main[p+8:p+24].split(b'\0')[0]==b'__LINKEDIT':continue
 assert main[p:p+s]==b[p:p+s]
for k in [5,7]:assert blobs(main).get(k)==blobs(b).get(k)
info=plistlib.loads(files[APP+'Info.plist']);oi=plistlib.loads(old[APP+'Info.plist'])
assert info['CFBundleDisplayName']=='VVebo 17E' and info['CFBundleVersion']=='4.1705'
for k in ['CFBundleDisplayName','CFBundleVersion','VVProfile17Compatibility']:info.pop(k,None);oi.pop(k,None)
assert info==oi
signature(main,files[APP+'Info.plist'],files[APP+'_CodeSignature/CodeResources'])
res=plistlib.loads(files[APP+'_CodeSignature/CodeResources'])
for n,v in res['files'].items():
 if APP+n in files:assert (v['hash'] if isinstance(v,dict) else v)==hashlib.sha1(files[APP+n]).digest(),n
assert files[APP+'Frameworks/VVProfile15.framework/VVProfile15']==old[APP+'Frameworks/VVProfile15.framework/VVProfile15']
print('PASS: exactly 3 files changed from verified A; 34 bounded instruction replacements; original framework, resources, callers, text geometry and load commands preserved; D helper/gates absent; entitlements and SHA256 code/resource hashes verified.')
print('LIMIT: complete launch, login, manual cloud-menu UI, signing trust and live network still require device validation. No display changes.')
