"""Execute packaged feature boundaries, not whole app or real Swift runtime."""
import json,zipfile,struct,sys
from pathlib import Path
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
BASE=0x100000000;STOP=0x300000;SP=0x20fff0;ARRAY=0x101000
manifest=json.loads(Path(sys.argv[2]).read_text());retain=BASE+int(manifest['bridge_retain_stub'],16)
with zipfile.ZipFile(sys.argv[1]) as z:b=z.read('Payload/VVebo.app/VVebo')
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x800000);u.mem_write(BASE,b);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x20000);u.mem_map(STOP,0x1000)
calls=[]
def hook(u,a,size,data):
 if a==retain:
  p=u.reg_read(UC_ARM64_REG_X0);assert p==ARRAY;calls.append(p)
  count=struct.unpack('<Q',u.mem_read(ARRAY+8,8))[0];u.mem_write(ARRAY+8,struct.pack('<Q',count+1));u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
u.hook_add(UC_HOOK_CODE,hook)
for p in manifest['patches']:
 off=p['file_offset']
 if p['after']=='000080d2':continue
 u.mem_write(ARRAY,struct.pack('<QQQQ',0x12340000,1,2,0xabcdef));before=bytes(u.mem_read(ARRAY,32));calls.clear()
 u.reg_write(UC_ARM64_REG_SP,SP);u.reg_write(UC_ARM64_REG_LR,STOP);u.reg_write(UC_ARM64_REG_FP,0xdeadbeef)
 for i in range(29):u.reg_write(globals()['UC_ARM64_REG_X'+str(i)],ARRAY if i==0 else 0x101100+i*16)
 regs=[u.reg_read(globals()['UC_ARM64_REG_X'+str(i)]) for i in range(29)]
 u.emu_start(BASE+off,STOP,count=50)
 assert u.reg_read(UC_ARM64_REG_PC)==STOP and u.reg_read(UC_ARM64_REG_SP)==SP and u.reg_read(UC_ARM64_REG_FP)==0xdeadbeef
 assert [u.reg_read(globals()['UC_ARM64_REG_X'+str(i)]) for i in range(29)]==regs
 if off==0x31575c:
  assert calls==[ARRAY] and struct.unpack('<Q',u.mem_read(ARRAY+8,8))[0]==2
  assert bytes(u.mem_read(ARRAY,8))==before[:8] and bytes(u.mem_read(ARRAY+16,16))==before[16:]
 else:assert not calls and bytes(u.mem_read(ARRAY,32))==before
print('PASS: packaged ARM64 for 27 Void boundaries returns immediately with unchanged stack/registers/local array; config conversion returns the same array with one owned retain. No callbacks, CloudKit calls or error/success objects are created at these boundaries.')
print('LIMIT: the Swift retain implementation is mocked; these are function-boundary tests, not complete app UI or ownership integration.')
