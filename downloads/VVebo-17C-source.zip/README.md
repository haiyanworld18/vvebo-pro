# iPhone17 Cloud compatibility C

Incremental, user-approved cloud-disablement experiment based on exact B output.
The uploaded B crash report identifies an unhandled CloudKit exception in the account-view cloud metadata query. B's container skips did not cover operation creation/deallocation on this path.

    python make_c.py /path/to/VVebo-3.3.31-iPhone17-CloudCompat-B.ipa /path/to/output
    python verify_c.py /path/to/VVebo-3.3.31-iPhone17-CloudCompat-B.ipa /path/to/output/VVebo-3.3.31-iPhone17-CloudCompat-C.ipa

The caller-slice tests additionally require Python package unicorn:

    python test_login_arm64.py /path/to/VVebo-3.3.31-iPhone17-CloudCompat-B.ipa /path/to/output/VVebo-3.3.31-iPhone17-CloudCompat-C.ipa

Two exact BL call sites (0x241944 and 0xc9220) are replaced with NOPs. Their targets are paired specialized cloud account-metadata queries; the logged path is 0x241944 -> 0x32b410. Neither caller consumes the return register; both retain their normal argument/context cleanup. No success callback, purchase flag or authorization state is fabricated. Existing local state is not changed by new instructions, and cloud-derived status will no longer refresh through these paths.

The machine-code tests mock Swift runtime and cloud-query calls. They check that the caller avoids the query while preserving model retains/releases and temporary weak-context cleanup. They do not prove complete app behavior, persistent data preservation, on-device startup or login.

The package is build 4.1703, display name VVebo 17C. Existing B cloud-container skips remain; the networking framework and entitlement blobs remain unchanged. No new proxy or signing material is included. Full on-device validation remains outstanding.
