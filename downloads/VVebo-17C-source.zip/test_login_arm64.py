"""Run actual caller instruction slices with mocked Swift runtime calls.
Checks that disabled cloud queries are not entered, while each caller's account
retain/release and temporary weak-context cleanup remain balanced.
"""
import sys,struct,zipfile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
BASE=0x100000000;BOX=0x300001000;MODEL=0x300002000;OWNER=0x300003000;CLOUD=0x300004000;STRING=0x300005000;WEAK_TARGET=0x300006000
class CloudQueryEntered(Exception):pass

def read(path):
 with zipfile.ZipFile(path) as z:return z.read('Payload/VVebo.app/VVebo')
def execute(binary,which):
 uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM);uc.mem_map(BASE,0x900000);uc.mem_map(0x300000000,0x10000);uc.mem_map(0x400000000,0x10000)
 p=32
 for _ in range(struct.unpack_from('<I',binary,16)[0]):
  c,s=struct.unpack_from('<II',binary,p)
  if c==0x19:
   va,vs,off,fs=struct.unpack_from('<4Q',binary,p+24)
   if fs:uc.mem_write(va,binary[off:off+fs])
  p+=s
 before=bytes(range(64));uc.mem_write(MODEL,before);uc.mem_write(OWNER+32,struct.pack('<Q',WEAK_TARGET))
 stats={'retains':0,'model_releases':0,'box_releases':0,'string_releases':0,'query_calls':0,'completed':False}
 start,end,target=(0x241918,0x241960,0x32b410) if which==0 else (0xc91f4,0xc923c,0x32baac)
 values={UC_ARM64_REG_X0:BOX,UC_ARM64_REG_X20:STRING,UC_ARM64_REG_X22:CLOUD,UC_ARM64_REG_X23:0x72657375,UC_ARM64_REG_X25:32,UC_ARM64_REG_SP:0x40000fff0}
 if which==0:values.update({UC_ARM64_REG_X19:OWNER,UC_ARM64_REG_X21:MODEL})
 else:values.update({UC_ARM64_REG_X19:MODEL,UC_ARM64_REG_X21:OWNER})
 for reg,val in values.items():uc.reg_write(reg,val)
 def ret(value):uc.reg_write(UC_ARM64_REG_X0,value);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))
 def callback(uc,pc,size,data):
  x0=uc.reg_read(UC_ARM64_REG_X0)
  if pc==BASE+target:stats['query_calls']+=1;raise CloudQueryEntered()
  if pc==BASE+0x565ce0:
   assert x0==BOX+16 and uc.reg_read(UC_ARM64_REG_X1)==WEAK_TARGET
   uc.mem_write(x0,struct.pack('<Q',WEAK_TARGET));ret(x0)
  elif pc==BASE+0x565c20:
   assert x0==MODEL;stats['retains']+=1;ret(x0)
  elif pc==BASE+0x5659b0:
   assert x0==STRING;stats['string_releases']+=1;ret(0)
  elif pc==BASE+0x565c08:
   if x0==MODEL:stats['model_releases']+=1
   elif x0==BOX:stats['box_releases']+=1;uc.mem_write(BOX+16,b'\0'*8)
   else:raise AssertionError(('unexpected release',hex(x0)))
   ret(0)
 uc.hook_add(UC_HOOK_CODE,callback)
 try:
  uc.emu_start(BASE+start,BASE+end,count=1000)
  assert uc.reg_read(UC_ARM64_REG_PC)==BASE+end;stats['completed']=True
 except CloudQueryEntered:pass
 assert bytes(uc.mem_read(MODEL,64))==before,'Account state altered'
 stats['context_cleared']=bytes(uc.mem_read(BOX+16,8))==b'\0'*8
 return stats
if len(sys.argv)!=3:raise SystemExit('Usage: test_login_arm64.py B_IPA C_IPA')
a=read(sys.argv[1]);b=read(sys.argv[2])
for which in [0,1]:
 old=execute(a,which);assert old['query_calls']==1 and not old['completed']
 new=execute(b,which)
 assert new=={'retains':1,'model_releases':1,'box_releases':1,'string_releases':1,'query_calls':0,'completed':True,'context_cleared':True},new
print('PASS: both compiled C caller slices skip the unavailable cloud query, balance account retains/releases, release temporary contexts/strings, and leave modeled local account bytes unchanged.')
print('LIMIT: Swift runtime calls and the cloud query are mocked. Complete login, persistent storage, UI, other callbacks and on-device behavior are not tested.')
