from pathlib import Path
import struct,zipfile,plistlib,hashlib,sys
from validation_helpers import cmds,signature
from macho_helpers import blobs
if len(sys.argv)!=3:raise SystemExit('Usage: verify_c.py B_IPA C_IPA')
a=Path(sys.argv[1]);b=Path(sys.argv[2]);APP='Payload/VVebo.app/'
assert hashlib.sha256(a.read_bytes()).hexdigest()=='d1480ea5bf37590b0b4b4b66d01b392393a4cbdb07f76555263c6411117fd363'
with zipfile.ZipFile(a) as z:old={n:z.read(n) for n in z.namelist()}
with zipfile.ZipFile(b) as z:
 assert z.testzip() is None;new={n:z.read(n) for n in z.namelist()}
assert set(old)==set(new)
assert {n for n in old if old[n]!=new[n]}=={APP+'VVebo',APP+'Info.plist',APP+'_CodeSignature/CodeResources'}
base=old[APP+'VVebo'];main=new[APP+'VVebo']
def text_range(b):
 for p,c,s in cmds(b):
  if c!=0x19:continue
  for i in range(struct.unpack_from('<I',b,p+64)[0]):
   q=p+72+80*i
   if b[q:q+16].split(b'\0')[0]==b'__text':
    size,off=struct.unpack_from('<QI',b,q+40);return off,off+size
 raise AssertionError('__text')
lo,hi=text_range(base);expected=bytearray(base[lo:hi])
for off,target in [(0x241944,0x32b410),(0xc9220,0x32baac)]:
 word=struct.unpack_from('<I',base,off)[0];assert word&0xfc000000==0x94000000
 imm=word&0x3ffffff
 if imm&(1<<25):imm-=1<<26
 assert off+(imm<<2)==target
 expected[off-lo:off-lo+4]=bytes.fromhex('1f2003d5')
 # Neither caller consumes the return value: its next instruction resets x0.
 assert base[off+4:off+8]==bytes.fromhex('e00314aa') # mov x0, x20
assert main[lo:hi]==bytes(expected)
info=plistlib.loads(new[APP+'Info.plist']);prev=plistlib.loads(old[APP+'Info.plist'])
assert info['CFBundleVersion']=='4.1703' and info['CFBundleDisplayName']=='VVebo 17C'
assert info['VVProfile17Compatibility']=='cloud-containers-and-account-query-disabled-c'
for k in ['CFBundleVersion','CFBundleDisplayName','VVProfile17Compatibility']:info.pop(k);prev.pop(k)
assert info==prev
signature(main,new[APP+'Info.plist'],new[APP+'_CodeSignature/CodeResources'])
for k in [5,7]:assert blobs(main).get(k)==blobs(base).get(k)
assert new[APP+'Frameworks/VVProfile15.framework/VVProfile15']==old[APP+'Frameworks/VVProfile15.framework/VVProfile15']
print('PASS: exact 2 call-site changes versus B, void-return use, all other instruction bytes preserved, 3 changed files only, framework and entitlements unchanged, build markers and signatures valid.')
print('NOT VERIFIED: on-device login, relaunch with saved account, full UI/callback behavior, profiles/pagination, or other cloud paths.')
