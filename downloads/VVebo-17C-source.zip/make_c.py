from pathlib import Path
import zipfile,plistlib,struct,hashlib,json,sys
from macho_helpers import sign
if len(sys.argv)!=3:raise SystemExit('Usage: make_c.py BASELINE_B_IPA OUTPUT_DIRECTORY')
base=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
assert hashlib.sha256(base.read_bytes()).hexdigest()=='d1480ea5bf37590b0b4b4b66d01b392393a4cbdb07f76555263c6411117fd363'
APP='Payload/VVebo.app/'
# The first call is the exact login/relaunch CloudKit query path in the report.
# The second is the paired account-view query specialization. Both callers ignore
# the return register and retain their own balanced argument/context cleanup.
CALLS={0x241944:0x32b410,0xc9220:0x32baac}
NOP=bytes.fromhex('1f2003d5')
with zipfile.ZipFile(base) as z:
 files={i.filename:z.read(i.filename) for i in z.infolist()};metadata={i.filename:i for i in z.infolist()}
main=bytearray(files[APP+'VVebo']);manifest=[]
for off,target in CALLS.items():
 word=struct.unpack_from('<I',main,off)[0];assert word&0xfc000000==0x94000000
 imm=word&0x3ffffff
 if imm&(1<<25):imm-=1<<26
 assert off+(imm<<2)==target
 manifest.append({'file_offset':hex(off),'original_target':hex(target),'before':main[off:off+4].hex(),'after':NOP.hex(),'purpose':'Do not issue unavailable cloud account metadata query; retain existing local state and caller cleanup'})
 main[off:off+4]=NOP
info=plistlib.loads(files[APP+'Info.plist']);assert info['CFBundleVersion']=='4.1702'
info['CFBundleDisplayName']='VVebo 17C';info['CFBundleVersion']='4.1703';info['VVProfile17Compatibility']='cloud-containers-and-account-query-disabled-c'
files[APP+'Info.plist']=plistlib.dumps(info,fmt=plistlib.FMT_BINARY,sort_keys=False)
resourcepath=APP+'_CodeSignature/CodeResources';resources=plistlib.loads(files[resourcepath]);legacy=resources.setdefault('files',{})
if 'Info.plist' in legacy:
 prior=legacy['Info.plist'];digest=hashlib.sha1(files[APP+'Info.plist']).digest()
 if isinstance(prior,dict):prior=dict(prior);prior['hash']=digest;legacy['Info.plist']=prior
 else:legacy['Info.plist']=digest
files[resourcepath]=plistlib.dumps(resources,fmt=plistlib.FMT_XML,sort_keys=True)
files[APP+'VVebo'],_=sign(main,info['CFBundleIdentifier'],files[APP+'Info.plist'],files[resourcepath])
target=out/'VVebo-3.3.31-iPhone17-CloudCompat-C.ipa'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in files.items():
  old=metadata[name];meta=zipfile.ZipInfo(name,old.date_time);meta.external_attr=old.external_attr;meta.create_system=old.create_system;meta.compress_type=zipfile.ZIP_DEFLATED;z.writestr(meta,data)
(out/'iPhone17-C-patch-manifest.json').write_text(json.dumps({'baseline':'17B','scope':'User-approved cloud feature disablement: bypass login/account-view cloud query entry points without writing account or purchase flags','instruction_patches':manifest},indent=2)+'\n')
print(target.name,'bytes',target.stat().st_size,'SHA256',hashlib.sha256(target.read_bytes()).hexdigest())
